﻿"use strict";

/*
 * TREBA SCHEDULING / ALLOCATION / QUEUE ENGINE
 *
 * Core operating model:
 *
 *   Route + travel date + time block
 *             ↓
 *   Scheduling pool
 *             ↓
 *   Up to 5 driver requests
 *             ↓
 *   2-hour response window
 *             ↓
 *   ACCEPT → scheduled supply
 *   DECLINE / TIMEOUT → next candidate
 *             ↓
 *   Target reached OR candidates exhausted
 *
 * Time blocks are allocation pools, not mandatory departure times.
 */

const BATCH_SIZE = 5;
const RESPONSE_WINDOW_HOURS = 2;

const TIME_BLOCKS = {
  MORNING: {
    code: "05_09",
    label: "05:00–09:00",
    start: "05:00",
    end: "09:00",
  },
  LATE_MORNING: {
    code: "09_12",
    label: "09:00–12:00",
    start: "09:00",
    end: "12:00",
  },
};

function getTimeBlock(code) {
  return Object.values(TIME_BLOCKS).find(
    (block) => block.code === code
  ) || null;
}

function normalizeDate(value) {
  const date = String(value || "").trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new Error(
      "travel_date must use YYYY-MM-DD format."
    );
  }

  return date;
}

function normalizePositiveInteger(value, field) {
  const number = Number(value);

  if (!Number.isInteger(number) || number <= 0) {
    throw new Error(`${field} must be a positive integer.`);
  }

  return number;
}

function normalizeDriverIds(driverIds) {
  if (!Array.isArray(driverIds)) {
    throw new Error(
      "candidate_driver_ids must be an array."
    );
  }

  const unique = [];

  for (const value of driverIds) {
    const id = Number(value);

    if (
      Number.isInteger(id) &&
      id > 0 &&
      !unique.includes(id)
    ) {
      unique.push(id);
    }
  }

  return unique;
}

function addResponseWindow(date = new Date()) {
  return new Date(
    date.getTime() +
      RESPONSE_WINDOW_HOURS * 60 * 60 * 1000
  );
}

/*
 * Creates the scheduling tables.
 *
 * We intentionally use Treba-specific table names so this module
 * does not collide with existing route/booking tables.
 */
async function ensureSchedulingSchema(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_scheduling_pools (
      id BIGSERIAL PRIMARY KEY,

      route_id BIGINT NOT NULL,
      travel_date DATE NOT NULL,

      time_block_code VARCHAR(30) NOT NULL,
      time_block_start TIME NOT NULL,
      time_block_end TIME NOT NULL,

      target_vehicles INTEGER NOT NULL
        CHECK (target_vehicles > 0),

      scheduled_vehicles INTEGER NOT NULL DEFAULT 0
        CHECK (scheduled_vehicles >= 0),

      status VARCHAR(30) NOT NULL DEFAULT 'OPEN',

      candidate_driver_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
      next_candidate_index INTEGER NOT NULL DEFAULT 0,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_scheduling_pools_route_date
    ON treba_scheduling_pools(
      route_id,
      travel_date,
      time_block_code
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_allocation_requests (
      id BIGSERIAL PRIMARY KEY,

      pool_id BIGINT NOT NULL
        REFERENCES treba_scheduling_pools(id)
        ON DELETE CASCADE,

      driver_id BIGINT NOT NULL,

      batch_number INTEGER NOT NULL,
      request_order INTEGER NOT NULL,

      status VARCHAR(30) NOT NULL DEFAULT 'PENDING',

      sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at TIMESTAMPTZ NOT NULL,
      responded_at TIMESTAMPTZ,

      response_note TEXT,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      UNIQUE(pool_id, driver_id)
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_allocation_requests_pool
    ON treba_allocation_requests(pool_id, status)
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_scheduled_supply (
      id BIGSERIAL PRIMARY KEY,

      pool_id BIGINT NOT NULL
        REFERENCES treba_scheduling_pools(id)
        ON DELETE CASCADE,

      route_id BIGINT NOT NULL,
      driver_id BIGINT NOT NULL,
      travel_date DATE NOT NULL,

      time_block_code VARCHAR(30) NOT NULL,

      preferred_departure_time TIME,

      vehicle_id BIGINT,
      seat_capacity INTEGER,

      starting_fare NUMERIC(12,2),

      status VARCHAR(30) NOT NULL DEFAULT 'SCHEDULED',

      available_seats INTEGER,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      UNIQUE(pool_id, driver_id)
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_scheduled_supply_route_date
    ON treba_scheduled_supply(
      route_id,
      travel_date,
      time_block_code,
      status
    )
  `);
}

/*
 * Create a scheduling pool.
 */
async function createSchedulingPool(
  pool,
  {
    routeId,
    travelDate,
    timeBlockCode,
    targetVehicles,
    candidateDriverIds,
  }
) {
  const route = normalizePositiveInteger(
    routeId,
    "routeId"
  );

  const date = normalizeDate(travelDate);

  const block = getTimeBlock(timeBlockCode);

  if (!block) {
    throw new Error(
      "Invalid time block. Use 05_09 or 09_12."
    );
  }

  const target = normalizePositiveInteger(
    targetVehicles,
    "targetVehicles"
  );

  const candidates =
    normalizeDriverIds(candidateDriverIds);

  if (candidates.length === 0) {
    throw new Error(
      "At least one candidate driver is required."
    );
  }

  const result = await pool.query(
    `
    INSERT INTO treba_scheduling_pools (
      route_id,
      travel_date,
      time_block_code,
      time_block_start,
      time_block_end,
      target_vehicles,
      candidate_driver_ids,
      status
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,'OPEN')
    RETURNING *
    `,
    [
      route,
      date,
      block.code,
      block.start,
      block.end,
      target,
      JSON.stringify(candidates),
    ]
  );

  const schedulingPool = result.rows[0];

  await issueNextBatch(
    pool,
    schedulingPool.id
  );

  const refreshed = await pool.query(
    `
    SELECT *
    FROM treba_scheduling_pools
    WHERE id = $1
    `,
    [schedulingPool.id]
  );

  return refreshed.rows[0];
}

/*
 * Send the next batch of up to five candidates.
 */
async function issueNextBatch(pool, poolId) {
  const poolResult = await pool.query(
    `
    SELECT *
    FROM treba_scheduling_pools
    WHERE id = $1
    FOR UPDATE
    `,
    [poolId]
  );

  const schedulingPool =
    poolResult.rows[0];

  if (!schedulingPool) {
    throw new Error(
      "Scheduling pool not found."
    );
  }

  if (
    schedulingPool.status !== "OPEN"
  ) {
    return [];
  }

  if (
    Number(schedulingPool.scheduled_vehicles) >=
    Number(schedulingPool.target_vehicles)
  ) {
    await pool.query(
      `
      UPDATE treba_scheduling_pools
      SET
        status = 'TARGET_REACHED',
        updated_at = NOW()
      WHERE id = $1
      `,
      [poolId]
    );

    return [];
  }

  const candidates =
    Array.isArray(
      schedulingPool.candidate_driver_ids
    )
      ? schedulingPool.candidate_driver_ids.map(Number)
      : [];

  let nextIndex =
    Number(
      schedulingPool.next_candidate_index || 0
    );

  const sentDrivers = await pool.query(
    `
    SELECT driver_id
    FROM treba_allocation_requests
    WHERE pool_id = $1
    `,
    [poolId]
  );

  const alreadyContacted = new Set(
    sentDrivers.rows.map(
      (row) => Number(row.driver_id)
    )
  );

  const batchNumber =
    (
      await pool.query(
        `
        SELECT COALESCE(
          MAX(batch_number),
          0
        ) + 1 AS batch
        FROM treba_allocation_requests
        WHERE pool_id = $1
        `,
        [poolId]
      )
    ).rows[0].batch;

  const selected = [];

  while (
    selected.length < BATCH_SIZE &&
    nextIndex < candidates.length
  ) {
    const driverId =
      Number(candidates[nextIndex]);

    nextIndex += 1;

    if (
      driverId > 0 &&
      !alreadyContacted.has(driverId)
    ) {
      selected.push(driverId);
    }
  }

  const expiresAt =
    addResponseWindow();

  for (
    let i = 0;
    i < selected.length;
    i++
  ) {
    await pool.query(
      `
      INSERT INTO treba_allocation_requests (
        pool_id,
        driver_id,
        batch_number,
        request_order,
        status,
        sent_at,
        expires_at
      )
      VALUES ($1,$2,$3,$4,'PENDING',NOW(),$5)
      ON CONFLICT (pool_id,driver_id)
      DO NOTHING
      `,
      [
        poolId,
        selected[i],
        batchNumber,
        i + 1,
        expiresAt,
      ]
    );
  }

  await pool.query(
    `
    UPDATE treba_scheduling_pools
    SET
      next_candidate_index = $2,
      updated_at = NOW()
    WHERE id = $1
    `,
    [poolId, nextIndex]
  );

  return selected;
}

/*
 * Timeout expired requests and continue the rolling queue.
 */
async function processSchedulingPool(pool, poolId) {
  await pool.query(
    `
    UPDATE treba_allocation_requests
    SET
      status = 'TIMEOUT',
      updated_at = NOW()
    WHERE pool_id = $1
      AND status = 'PENDING'
      AND expires_at <= NOW()
    `,
    [poolId]
  );

  const stateResult = await pool.query(
    `
    SELECT
      p.*,
      COUNT(
        CASE
          WHEN r.status = 'PENDING'
          THEN 1
        END
      )::int AS pending_requests
    FROM treba_scheduling_pools p
    LEFT JOIN treba_allocation_requests r
      ON r.pool_id = p.id
    WHERE p.id = $1
    GROUP BY p.id
    `,
    [poolId]
  );

  const state = stateResult.rows[0];

  if (!state) {
    throw new Error(
      "Scheduling pool not found."
    );
  }

  if (
    Number(state.scheduled_vehicles) >=
    Number(state.target_vehicles)
  ) {
    await pool.query(
      `
      UPDATE treba_scheduling_pools
      SET
        status = 'TARGET_REACHED',
        updated_at = NOW()
      WHERE id = $1
      `,
      [poolId]
    );

    return {
      status: "TARGET_REACHED",
    };
  }

  if (
    Number(state.pending_requests) === 0
  ) {
    const candidates =
      Array.isArray(
        state.candidate_driver_ids
      )
        ? state.candidate_driver_ids
        : [];

    if (
      Number(state.next_candidate_index) >=
      candidates.length
    ) {
      await pool.query(
        `
        UPDATE treba_scheduling_pools
        SET
          status = 'CANDIDATES_EXHAUSTED',
          updated_at = NOW()
        WHERE id = $1
        `,
        [poolId]
      );

      return {
        status: "CANDIDATES_EXHAUSTED",
      };
    }

    const issued = await issueNextBatch(
      pool,
      poolId
    );

    return {
      status: "NEW_BATCH_ISSUED",
      driverIds: issued,
    };
  }

  return {
    status: "WAITING",
    pendingRequests:
      Number(state.pending_requests),
  };
}

/*
 * Driver responds to an allocation request.
 */
async function respondToAllocation(
  pool,
  {
    requestId,
    driverId,
    decision,
    note,
    preferredDepartureTime,
    vehicleId,
    seatCapacity,
    startingFare,
  }
) {
  const requestNumber =
    normalizePositiveInteger(
      requestId,
      "requestId"
    );

  const driverNumber =
    normalizePositiveInteger(
      driverId,
      "driverId"
    );

  const normalizedDecision =
    String(decision || "")
      .trim()
      .toUpperCase();

  if (
    !["ACCEPT", "DECLINE"].includes(
      normalizedDecision
    )
  ) {
    throw new Error(
      "Decision must be ACCEPT or DECLINE."
    );
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const requestResult =
      await client.query(
        `
        SELECT
          r.*,
          p.route_id,
          p.travel_date,
          p.time_block_code,
          p.scheduled_vehicles,
          p.target_vehicles,
          p.status AS pool_status
        FROM treba_allocation_requests r
        JOIN treba_scheduling_pools p
          ON p.id = r.pool_id
        WHERE r.id = $1
          AND r.driver_id = $2
        FOR UPDATE
        `,
        [requestNumber, driverNumber]
      );

    const request =
      requestResult.rows[0];

    if (!request) {
      throw new Error(
        "Allocation request not found."
      );
    }

    if (
      request.status !== "PENDING"
    ) {
      throw new Error(
        `Allocation request is already ${request.status}.`
      );
    }

    if (
      new Date(request.expires_at)
        .getTime() <= Date.now()
    ) {
      await client.query(
        `
        UPDATE treba_allocation_requests
        SET
          status = 'TIMEOUT',
          updated_at = NOW()
        WHERE id = $1
        `,
        [requestNumber]
      );

      await client.query("COMMIT");

      return {
        status: "TIMEOUT",
        message:
          "The two-hour acceptance window has expired.",
      };
    }

    const scheduled =
      Number(
        request.scheduled_vehicles || 0
      );

    const target =
      Number(
        request.target_vehicles || 0
      );

    if (
      normalizedDecision === "ACCEPT"
    ) {

      if (scheduled >= target) {
        throw new Error(
          "The scheduling target has already been reached."
        );
      }

      await client.query(
        `
        UPDATE treba_allocation_requests
        SET
          status = 'ACCEPTED',
          responded_at = NOW(),
          response_note = $2,
          updated_at = NOW()
        WHERE id = $1
        `,
        [
          requestNumber,
          String(note || "").trim() || null,
        ]
      );

      await client.query(
        `
        INSERT INTO treba_scheduled_supply (
          pool_id,
          route_id,
          driver_id,
          travel_date,
          time_block_code,
          preferred_departure_time,
          vehicle_id,
          seat_capacity,
          starting_fare,
          status,
          available_seats
        )
        VALUES (
          $1,$2,$3,$4,$5,$6,$7,$8,$9,
          'SCHEDULED',
          $8
        )
        ON CONFLICT (pool_id,driver_id)
        DO UPDATE SET
          status = 'SCHEDULED',
          updated_at = NOW()
        `,
        [
          request.pool_id,
          request.route_id,
          driverNumber,
          request.travel_date,
          request.time_block_code,
          preferredDepartureTime || null,
          vehicleId || null,
          seatCapacity || null,
          startingFare || null,
        ]
      );

      await client.query(
        `
        UPDATE treba_scheduling_pools
        SET
          scheduled_vehicles =
            scheduled_vehicles + 1,
          status = CASE
            WHEN scheduled_vehicles + 1 >= target_vehicles
              THEN 'TARGET_REACHED'
            ELSE 'OPEN'
          END,
          updated_at = NOW()
        WHERE id = $1
        `,
        [request.pool_id]
      );

      await client.query("COMMIT");

      return {
        status: "ACCEPTED",
        poolId: request.pool_id,
        driverId: driverNumber,
        message:
          "Driver scheduled successfully.",
      };
    }

    await client.query(
      `
      UPDATE treba_allocation_requests
      SET
        status = 'DECLINED',
        responded_at = NOW(),
        response_note = $2,
        updated_at = NOW()
      WHERE id = $1
      `,
      [
        requestNumber,
        String(note || "").trim() || null,
      ]
    );

    await client.query("COMMIT");

    await processSchedulingPool(
      pool,
      request.pool_id
    );

    return {
      status: "DECLINED",
      poolId: request.pool_id,
      driverId: driverNumber,
      message:
        "Driver declined. Queue processing continued.",
    };

  } catch (error) {

    try {
      await client.query("ROLLBACK");
    } catch {}

    throw error;

  } finally {
    client.release();
  }
}

/*
 * Return queue state.
 */
async function getSchedulingPool(
  pool,
  poolId
) {
  const result = await pool.query(
    `
    SELECT
      p.*,
      COUNT(
        CASE
          WHEN r.status = 'PENDING'
          THEN 1
        END
      )::int AS pending_requests,
      COUNT(
        CASE
          WHEN r.status = 'ACCEPTED'
          THEN 1
        END
      )::int AS accepted_requests,
      COUNT(
        CASE
          WHEN r.status = 'DECLINED'
          THEN 1
        END
      )::int AS declined_requests,
      COUNT(
        CASE
          WHEN r.status = 'TIMEOUT'
          THEN 1
        END
      )::int AS timeout_requests
    FROM treba_scheduling_pools p
    LEFT JOIN treba_allocation_requests r
      ON r.pool_id = p.id
    WHERE p.id = $1
    GROUP BY p.id
    `,
    [poolId]
  );

  if (!result.rows[0]) {
    return null;
  }

  const requests = await pool.query(
    `
    SELECT *
    FROM treba_allocation_requests
    WHERE pool_id = $1
    ORDER BY batch_number, request_order
    `,
    [poolId]
  );

  const supply = await pool.query(
    `
    SELECT *
    FROM treba_scheduled_supply
    WHERE pool_id = $1
    ORDER BY created_at
    `,
    [poolId]
  );

  return {
    ...result.rows[0],
    allocation_requests:
      requests.rows,
    scheduled_supply:
      supply.rows,
  };
}

/*
 * Register API endpoints.
 *
 * These endpoints expect the existing application authentication
 * middleware to populate req.auth, as the credit module already does.
 */
function registerSchedulingRoutes(app, pool) {

  app.post(
    "/api/scheduling/initialize",
    async (req, res) => {
      try {

        if (!req.auth?.id) {
          return res.status(401).json({
            ok: false,
            message:
              "Authentication required.",
          });
        }

        await ensureSchedulingSchema(pool);

        const schedulingPool =
          await createSchedulingPool(
            pool,
            req.body || {}
          );

        res.status(201).json({
          ok: true,
          pool: schedulingPool,
        });

      } catch (error) {

        console.error(
          "POST /api/scheduling/initialize:",
          error
        );

        res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to initialize scheduling pool.",
        });
      }
    }
  );

  app.get(
    "/api/scheduling/pool/:id",
    async (req, res) => {
      try {

        if (!req.auth?.id) {
          return res.status(401).json({
            ok: false,
            message:
              "Authentication required.",
          });
        }

        await ensureSchedulingSchema(pool);

        const poolId =
          normalizePositiveInteger(
            req.params.id,
            "poolId"
          );

        const schedulingPool =
          await getSchedulingPool(
            pool,
            poolId
          );

        if (!schedulingPool) {
          return res.status(404).json({
            ok: false,
            message:
              "Scheduling pool not found.",
          });
        }

        res.json({
          ok: true,
          pool: schedulingPool,
        });

      } catch (error) {

        console.error(
          "GET /api/scheduling/pool/:id:",
          error
        );

        res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to load scheduling pool.",
        });
      }
    }
  );

  app.post(
    "/api/scheduling/pool/:id/process",
    async (req, res) => {
      try {

        if (!req.auth?.id) {
          return res.status(401).json({
            ok: false,
            message:
              "Authentication required.",
          });
        }

        await ensureSchedulingSchema(pool);

        const poolId =
          normalizePositiveInteger(
            req.params.id,
            "poolId"
          );

        const result =
          await processSchedulingPool(
            pool,
            poolId
          );

        res.json({
          ok: true,
          result,
        });

      } catch (error) {

        console.error(
          "POST /api/scheduling/pool/:id/process:",
          error
        );

        res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to process scheduling queue.",
        });
      }
    }
  );

  app.post(
    "/api/scheduling/request/:id/respond",
    async (req, res) => {
      try {

        const driverId = req.auth?.id;

        if (!driverId) {
          return res.status(401).json({
            ok: false,
            message:
              "Authentication required.",
          });
        }

        await ensureSchedulingSchema(pool);

        const result =
          await respondToAllocation(
            pool,
            {
              requestId:
                req.params.id,
              driverId,
              decision:
                req.body?.decision,
              note:
                req.body?.note,
              preferredDepartureTime:
                req.body
                  ?.preferred_departure_time,
              vehicleId:
                req.body?.vehicle_id,
              seatCapacity:
                req.body?.seat_capacity,
              startingFare:
                req.body?.starting_fare,
            }
          );

        res.json({
          ok: true,
          result,
        });

      } catch (error) {

        console.error(
          "POST /api/scheduling/request/:id/respond:",
          error
        );

        res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to respond to scheduling request.",
        });
      }
    }
  );
}

module.exports = {
  BATCH_SIZE,
  RESPONSE_WINDOW_HOURS,
  TIME_BLOCKS,
  ensureSchedulingSchema,
  createSchedulingPool,
  issueNextBatch,
  processSchedulingPool,
  respondToAllocation,
  getSchedulingPool,
  registerSchedulingRoutes,
};
