﻿import React, { useEffect, useState } from "react";
import { Plus, Trash2, Route, Clock3, Coins, Save } from "lucide-react";

const EMPTY_STOP = {
  town: "",
  distance_from_origin_km: "",
};

export default function RouteSetup() {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    origin_town: "",
    destination_town: "",
    frequency: "EVERY_DAY",
    direction: "ONE_WAY",
    time_block_code: "05_09",
    preferred_departure_time: "07:00",
    standard_pickup_point: "",
    standard_dropoff_point: "",
    corridor_starting_fare: "",
    seat_capacity: "",
    destination_distance_km: "",
    stops: [],
  });

  const token =
    typeof window !== "undefined"
      ? localStorage.getItem("treba_token")
      : null;

  async function loadRoutes() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch(
        "/api/driver/routes",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load routes."
        );
      }

      setRoutes(data.routes || []);

    } catch (err) {

      setError(
        err.message ||
          "Unable to load routes."
      );

    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadRoutes();
  }, []);

  function update(field, value) {
    setForm((current) => ({
      ...current,
      [field]: value,
    }));
  }

  function addStop() {
    setForm((current) => ({
      ...current,
      stops: [
        ...current.stops,
        {
          ...EMPTY_STOP,
        },
      ],
    }));
  }

  function removeStop(index) {
    setForm((current) => ({
      ...current,
      stops: current.stops.filter(
        (_, i) => i !== index
      ),
    }));
  }

  function updateStop(
    index,
    field,
    value
  ) {
    setForm((current) => ({
      ...current,
      stops: current.stops.map(
        (stop, i) =>
          i === index
            ? {
                ...stop,
                [field]: value,
              }
            : stop
      ),
    }));
  }

  async function saveRoute(event) {
    event.preventDefault();

    setSaving(true);
    setMessage("");
    setError("");

    try {

      if (
        !form.origin_town.trim() ||
        !form.destination_town.trim()
      ) {
        throw new Error(
          "Origin and destination towns are required."
        );
      }

      if (
        Number(form.corridor_starting_fare) < 60
      ) {
        throw new Error(
          "Starting fare must be at least N$60."
        );
      }

      if (
        Number(form.seat_capacity) <= 0
      ) {
        throw new Error(
          "Vehicle seat capacity is required."
        );
      }

      const response =
        await fetch(
          "/api/driver/routes",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type":
                "application/json",
            },
            body: JSON.stringify({
              ...form,
              corridor_starting_fare:
                Number(
                  form.corridor_starting_fare
                ),
              seat_capacity:
                Number(
                  form.seat_capacity
                ),
              destination_distance_km:
                form.destination_distance_km
                  ? Number(
                      form.destination_distance_km
                    )
                  : null,
              stops:
                form.stops.map(
                  (stop) => ({
                    town:
                      stop.town.trim(),
                    distance_from_origin_km:
                      stop.distance_from_origin_km
                        ? Number(
                            stop.distance_from_origin_km
                          )
                        : null,
                  })
                ),
            }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to save route."
        );
      }

      setMessage(
        "Route saved successfully."
      );

      setForm({
        origin_town: "",
        destination_town: "",
        frequency: "EVERY_DAY",
        direction: "ONE_WAY",
        time_block_code: "05_09",
        preferred_departure_time: "07:00",
        standard_pickup_point: "",
        standard_dropoff_point: "",
        corridor_starting_fare: "",
        seat_capacity: "",
        destination_distance_km: "",
        stops: [],
      });

      await loadRoutes();

    } catch (err) {

      setError(
        err.message ||
          "Unable to save route."
      );

    } finally {
      setSaving(false);
    }
  }

  async function deactivateRoute(id) {

    if (
      !window.confirm(
        "Deactivate this route?"
      )
    ) {
      return;
    }

    try {

      const response =
        await fetch(
          `/api/driver/routes/${id}`,
          {
            method: "DELETE",
            headers: {
              Authorization:
                `Bearer ${token}`,
            },
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to deactivate route."
        );
      }

      await loadRoutes();

    } catch (err) {

      setError(
        err.message ||
          "Unable to deactivate route."
      );
    }
  }

  return (
    <div className="space-y-8">

      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          Route Setup
        </h1>

        <p className="mt-1 text-muted-foreground">
          Create your town-to-town corridor, intermediate stops,
          operating block and starting fare. Treba uses this
          information for allocation and passenger matching.
        </p>
      </div>

      {message && (
        <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm">
          {message}
        </div>
      )}

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}

      <form
        onSubmit={saveRoute}
        className="rounded-2xl border border-border bg-card p-6 treba-shadow"
      >

        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <Route className="h-6 w-6" />
          </div>

          <div>
            <h2 className="text-lg font-bold">
              Create Route
            </h2>

            <p className="text-sm text-muted-foreground">
              One corridor can contain many towns.
            </p>
          </div>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Origin town
            </span>
            <input
              value={form.origin_town}
              onChange={(e) =>
                update(
                  "origin_town",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              placeholder="Windhoek"
              required
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Destination town
            </span>
            <input
              value={form.destination_town}
              onChange={(e) =>
                update(
                  "destination_town",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              placeholder="Walvis Bay"
              required
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Frequency
            </span>
            <select
              value={form.frequency}
              onChange={(e) =>
                update(
                  "frequency",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
            >
              <option value="EVERY_DAY">
                Every Day
              </option>
              <option value="MONDAY_FRIDAY">
                Monday–Friday
              </option>
            </select>
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Direction
            </span>
            <select
              value={form.direction}
              onChange={(e) =>
                update(
                  "direction",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
            >
              <option value="ONE_WAY">
                One Way
              </option>
              <option value="RETURN">
                Return
              </option>
            </select>
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Time block
            </span>
            <select
              value={form.time_block_code}
              onChange={(e) =>
                update(
                  "time_block_code",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
            >
              <option value="05_09">
                05:00–09:00
              </option>
              <option value="09_12">
                09:00–12:00
              </option>
            </select>
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Preferred departure
            </span>
            <input
              type="time"
              value={form.preferred_departure_time}
              onChange={(e) =>
                update(
                  "preferred_departure_time",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              required
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Vehicle seat capacity
            </span>
            <input
              type="number"
              min="1"
              value={form.seat_capacity}
              onChange={(e) =>
                update(
                  "seat_capacity",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              placeholder="5"
              required
            />
          </label>

          <label className="space-y-1.5">
            <span className="text-sm font-medium">
              Corridor starting fare per seat
            </span>
            <div className="relative">
              <Coins className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="number"
                min="60"
                step="5"
                value={
                  form.corridor_starting_fare
                }
                onChange={(e) =>
                  update(
                    "corridor_starting_fare",
                    e.target.value
                  )
                }
                className="w-full rounded-xl border border-border bg-background py-3 pl-9 pr-4"
                placeholder="280"
                required
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Treba uses this as the starting fare for the
              complete corridor and calculates intermediate fares.
            </p>
          </label>

          <label className="space-y-1.5 md:col-span-2">
            <span className="text-sm font-medium">
              Standard pickup point
            </span>
            <input
              value={
                form.standard_pickup_point
              }
              onChange={(e) =>
                update(
                  "standard_pickup_point",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              placeholder="Windhoek Main Bus Station"
            />
          </label>

          <label className="space-y-1.5 md:col-span-2">
            <span className="text-sm font-medium">
              Standard drop-off point
            </span>
            <input
              value={
                form.standard_dropoff_point
              }
              onChange={(e) =>
                update(
                  "standard_dropoff_point",
                  e.target.value
                )
              }
              className="w-full rounded-xl border border-border bg-background px-4 py-3"
              placeholder="Walvis Bay Pick-up Point"
            />
          </label>

        </div>

        <div className="mt-8 rounded-xl border border-border bg-muted/20 p-5">

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold">
                Intermediate towns
              </h3>

              <p className="text-sm text-muted-foreground">
                Add towns in route order. Distances are measured
                from the origin and feed the fare engine.
              </p>
            </div>

            <button
              type="button"
              onClick={addStop}
              className="inline-flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2 text-sm font-semibold"
            >
              <Plus className="h-4 w-4" />
              Add town
            </button>
          </div>

          <div className="mt-4 space-y-3">

            {form.stops.length === 0 && (
              <div className="rounded-xl border border-dashed border-border px-4 py-5 text-center text-sm text-muted-foreground">
                No intermediate towns added.
              </div>
            )}

            {form.stops.map(
              (stop, index) => (
                <div
                  key={index}
                  className="grid gap-3 md:grid-cols-[1fr_180px_auto]"
                >

                  <input
                    value={stop.town}
                    onChange={(e) =>
                      updateStop(
                        index,
                        "town",
                        e.target.value
                      )
                    }
                    className="rounded-xl border border-border bg-background px-4 py-3"
                    placeholder={`Stop ${index + 1}, e.g. Karibib`}
                  />

                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={
                      stop.distance_from_origin_km
                    }
                    onChange={(e) =>
                      updateStop(
                        index,
                        "distance_from_origin_km",
                        e.target.value
                      )
                    }
                    className="rounded-xl border border-border bg-background px-4 py-3"
                    placeholder="Distance km"
                  />

                  <button
                    type="button"
                    onClick={() =>
                      removeStop(index)
                    }
                    className="inline-flex items-center justify-center rounded-xl border border-border px-4 py-3 text-muted-foreground hover:text-red-600"
                    title="Remove stop"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>

                </div>
              )
            )}

          </div>

          <div className="mt-4 grid gap-4 md:grid-cols-2">

            <label className="space-y-1.5">
              <span className="text-sm font-medium">
                Total corridor distance (km)
              </span>
              <input
                type="number"
                min="1"
                step="0.1"
                value={
                  form.destination_distance_km
                }
                onChange={(e) =>
                  update(
                    "destination_distance_km",
                    e.target.value
                  )
                }
                className="w-full rounded-xl border border-border bg-background px-4 py-3"
                placeholder="395"
              />
            </label>

            <div className="flex items-end">
              <div className="w-full rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-sm">
                <div className="flex items-center gap-2 font-medium">
                  <Clock3 className="h-4 w-4 text-primary" />
                  Scheduling block
                </div>
                <div className="mt-1 text-muted-foreground">
                  {form.time_block_code === "05_09"
                    ? "05:00–09:00"
                    : "09:00–12:00"}
                  {" · "}
                  Depart around{" "}
                  {form.preferred_departure_time}
                </div>
              </div>
            </div>

          </div>

        </div>

        <button
          type="submit"
          disabled={saving}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-3 font-semibold text-primary-foreground disabled:opacity-60"
        >
          <Save className="h-4 w-4" />
          {saving
            ? "Saving..."
            : "Save Route"}
        </button>

      </form>

      <section className="space-y-4">

        <div>
          <h2 className="text-lg font-bold">
            My Routes
          </h2>
          <p className="text-sm text-muted-foreground">
            Routes available to Treba's allocation engine.
          </p>
        </div>

        {loading && (
          <div className="rounded-xl border border-border bg-card p-5 text-sm text-muted-foreground">
            Loading routes...
          </div>
        )}

        {!loading &&
          routes.length === 0 && (
            <div className="rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">
              No active routes yet.
            </div>
          )}

        {!loading &&
          routes.map((route) => (
            <div
              key={route.id}
              className="rounded-2xl border border-border bg-card p-5 treba-shadow"
            >

              <div className="flex flex-wrap items-start justify-between gap-4">

                <div>
                  <div className="text-lg font-bold">
                    {route.origin_town}
                    {" → "}
                    {route.destination_town}
                  </div>

                  <div className="mt-1 text-sm text-muted-foreground">
                    {route.frequency ===
                    "MONDAY_FRIDAY"
                      ? "Monday–Friday"
                      : "Every Day"}
                    {" · "}
                    {route.time_block_code ===
                    "05_09"
                      ? "05:00–09:00"
                      : "09:00–12:00"}
                    {" · "}
                    departure{" "}
                    {String(
                      route.preferred_departure_time
                    ).slice(0, 5)}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-lg font-bold">
                    N$
                    {Number(
                      route.corridor_starting_fare
                    ).toLocaleString()}
                  </div>

                  <div className="text-xs text-muted-foreground">
                    starting fare / seat
                  </div>
                </div>

              </div>

              {Array.isArray(route.stops) &&
                route.stops.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {route.stops.map(
                      (stop) => (
                        <span
                          key={stop.id}
                          className="rounded-full bg-muted px-3 py-1 text-xs"
                        >
                          {stop.town}
                        </span>
                      )
                    )}
                  </div>
                )}

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">

                <div className="text-sm text-muted-foreground">
                  Vehicle seats:{" "}
                  <span className="font-medium text-foreground">
                    {route.seat_capacity}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    deactivateRoute(
                      route.id
                    )
                  }
                  className="inline-flex items-center gap-2 rounded-xl border border-border px-4 py-2 text-sm font-semibold text-muted-foreground hover:text-red-600"
                >
                  <Trash2 className="h-4 w-4" />
                  Deactivate
                </button>

              </div>

            </div>
          ))}

      </section>

    </div>
  );
}
