const express = require("express");

const CREDIT_PRICE_PER_SEAT = 5;
const MIN_RECHARGE = 100;
const TRIAL_TRIPS = 10;
const AGENT_COMMISSION_RATE = 0.10;
const DEFAULT_AGENT_FLOAT_LIMIT = 2000;

function normalisePhone(value) {
  return String(value || "").replace(/\s+/g, "").trim();
}

function createReference(prefix) {
  const now = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();

  return `${prefix}-${now}-${random}`;
}

async function ensureCreditAgentSchema(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS credit_wallets (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL UNIQUE,
      balance NUMERIC(12,2) NOT NULL DEFAULT 0,
      currency VARCHAR(3) NOT NULL DEFAULT 'NAD',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS credit_transactions (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      type VARCHAR(40) NOT NULL,
      amount NUMERIC(12,2) NOT NULL,
      seats INTEGER,
      booking_id BIGINT,
      payment_method VARCHAR(40),
      reference VARCHAR(80) NOT NULL UNIQUE,
      description TEXT,
      created_by BIGINT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_credit_transactions_user
    ON credit_transactions(user_id, created_at DESC)
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS driver_credit_profiles (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL UNIQUE,
      seat_capacity INTEGER NOT NULL DEFAULT 1,
      trial_credit_granted BOOLEAN NOT NULL DEFAULT FALSE,
      low_credit_percent NUMERIC(5,2) NOT NULL DEFAULT 10,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_profiles (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL UNIQUE,
      agent_code VARCHAR(30) NOT NULL UNIQUE,
      status VARCHAR(20) NOT NULL DEFAULT 'active',
      float_limit NUMERIC(12,2) NOT NULL DEFAULT 2000,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_cash_requests (
      id BIGSERIAL PRIMARY KEY,
      customer_user_id BIGINT NOT NULL,
      agent_user_id BIGINT,
      amount NUMERIC(12,2) NOT NULL,
      reference VARCHAR(80) NOT NULL UNIQUE,
      status VARCHAR(30) NOT NULL DEFAULT 'WAITING_FOR_AGENT',
      customer_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
      agent_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_liabilities (
      id BIGSERIAL PRIMARY KEY,
      agent_user_id BIGINT NOT NULL,
      cash_request_id BIGINT NOT NULL UNIQUE,
      amount NUMERIC(12,2) NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'OUTSTANDING',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      settled_at TIMESTAMPTZ
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_settlements (
      id BIGSERIAL PRIMARY KEY,
      agent_user_id BIGINT NOT NULL,
      amount NUMERIC(12,2) NOT NULL,
      reference VARCHAR(80) NOT NULL UNIQUE,
      status VARCHAR(30) NOT NULL DEFAULT 'PAYMENT_PENDING',
      payment_reference VARCHAR(120),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      verified_at TIMESTAMPTZ
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_commission_transactions (
      id BIGSERIAL PRIMARY KEY,
      agent_user_id BIGINT NOT NULL,
      settlement_id BIGINT NOT NULL UNIQUE,
      gross_settlement NUMERIC(12,2) NOT NULL,
      commission_rate NUMERIC(6,4) NOT NULL DEFAULT 0.10,
      commission_amount NUMERIC(12,2) NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'EARNED',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agent_commission_wallets (
      id BIGSERIAL PRIMARY KEY,
      agent_user_id BIGINT NOT NULL UNIQUE,
      balance NUMERIC(12,2) NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

async function ensureUserCreditWallet(pool, userId) {
  await pool.query(
    `
    INSERT INTO credit_wallets (user_id)
    VALUES ($1)
    ON CONFLICT (user_id) DO NOTHING
    `,
    [userId]
  );
}

async function getCreditBalance(pool, userId) {
  await ensureUserCreditWallet(pool, userId);

  const result = await pool.query(
    `
    SELECT balance
    FROM credit_wallets
    WHERE user_id = $1
    `,
    [userId]
  );

  return Number(result.rows[0]?.balance || 0);
}

async function addCredits(
  pool,
  {
    userId,
    amount,
    type,
    reference,
    paymentMethod,
    description,
    createdBy,
  }
) {
  if (Number(amount) <= 0) {
    throw new Error("Credit amount must be greater than zero.");
  }

  await ensureUserCreditWallet(pool, userId);

  await pool.query("BEGIN");

  try {
    await pool.query(
      `
      UPDATE credit_wallets
      SET balance = balance + $1,
          updated_at = NOW()
      WHERE user_id = $2
      `,
      [amount, userId]
    );

    await pool.query(
      `
      INSERT INTO credit_transactions (
        user_id,
        type,
        amount,
        payment_method,
        reference,
        description,
        created_by
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      `,
      [
        userId,
        type,
        amount,
        paymentMethod || null,
        reference,
        description || null,
        createdBy || null,
      ]
    );

    await pool.query("COMMIT");
  } catch (error) {
    await pool.query("ROLLBACK");
    throw error;
  }
}

async function deductCredits(
  pool,
  {
    userId,
    seats,
    bookingId,
  }
) {
  const cleanSeats = Number(seats);

  if (!Number.isInteger(cleanSeats) || cleanSeats <= 0) {
    throw new Error("Seats must be a positive integer.");
  }

  const amount = cleanSeats * CREDIT_PRICE_PER_SEAT;
  const reference = createReference("TRB-BOOK");

  await ensureUserCreditWallet(pool, userId);

  await pool.query("BEGIN");

  try {
    const balanceResult = await pool.query(
      `
      SELECT balance
      FROM credit_wallets
      WHERE user_id = $1
      FOR UPDATE
      `,
      [userId]
    );

    const balance = Number(balanceResult.rows[0]?.balance || 0);

    if (balance < amount) {
      throw new Error("Insufficient Treba credit.");
    }

    await pool.query(
      `
      UPDATE credit_wallets
      SET balance = balance - $1,
          updated_at = NOW()
      WHERE user_id = $2
      `,
      [amount, userId]
    );

    await pool.query(
      `
      INSERT INTO credit_transactions (
        user_id,
        type,
        amount,
        seats,
        booking_id,
        reference,
        description
      )
      VALUES ($1,'BOOKING_DEBIT',$2,$3,$4,$5,$6)
      `,
      [
        userId,
        amount,
        cleanSeats,
        bookingId || null,
        reference,
        `N$${CREDIT_PRICE_PER_SEAT} per confirmed passenger seat`,
      ]
    );

    await pool.query("COMMIT");

    return {
      amount,
      reference,
      balanceAfter: balance - amount,
    };
  } catch (error) {
    await pool.query("ROLLBACK");
    throw error;
  }
}

function registerCreditAgentRoutes(app, pool, authenticateToken) {
  ensureCreditAgentSchema(pool)
    .then(() => {
      console.log("Treba credit/agent database schema ready.");
    })
    .catch((error) => {
      console.error(
        "Treba credit/agent schema initialization failed:",
        error
      );
    });

  /*
   * GET CREDIT WALLET
   */
  app.get("/api/credits", async (req, res) => {
    try {
      const userId = req.auth?.id;

      if (!userId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const balance = await getCreditBalance(pool, userId);

      const transactions = await pool.query(
        `
        SELECT
          id,
          type,
          amount,
          seats,
          payment_method,
          reference,
          description,
          created_at
        FROM credit_transactions
        WHERE user_id = $1
        ORDER BY created_at DESC
        LIMIT 50
        `,
        [userId]
      );

      const profile = await pool.query(
        `
        SELECT
          seat_capacity,
          trial_credit_granted
        FROM driver_credit_profiles
        WHERE user_id = $1
        `,
        [userId]
      );

      res.json({
        ok: true,
        balance,
        currency: "NAD",
        pricePerSeat: CREDIT_PRICE_PER_SEAT,
        minimumRecharge: MIN_RECHARGE,
        warningLevels: [10, 5, 2],
        driverProfile: profile.rows[0] || null,
        transactions: transactions.rows,
      });
    } catch (error) {
      console.error("GET /api/credits:", error);

      res.status(500).json({
        ok: false,
        message: "Unable to load credit account.",
      });
    }
  });

  /*
   * ONLINE / VERIFIED RECHARGE
   *
   * The payment provider should call this only AFTER
   * confirming the payment.
   */
  /*
   * ONLINE CREDIT RECHARGE REQUEST
   *
   * IMPORTANT:
   * Credits are NOT added here.
   * A verified payment service or admin verification
   * must approve the request first.
   */
  app.post("/api/credits/recharge", async (req, res) => {
    try {
      const userId = req.auth?.id;

      if (!userId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const amount = Number(req.body?.amount);
      const paymentMethod = String(
        req.body?.payment_method || ""
      ).trim();

      if (!Number.isFinite(amount) || amount <= 0) {
        return res.status(400).json({
          ok: false,
          message: "Invalid recharge amount.",
        });
      }

      if (amount < MIN_RECHARGE) {
        return res.status(400).json({
          ok: false,
          message: `Minimum recharge is N$${MIN_RECHARGE}.`,
        });
      }

      const allowedMethods = [
        "card",
        "mobile_money",
        "paytoday",
        "eft",
      ];

      if (!allowedMethods.includes(paymentMethod)) {
        return res.status(400).json({
          ok: false,
          message: "Unsupported payment method.",
        });
      }

      await pool.query(`
        CREATE TABLE IF NOT EXISTS credit_recharge_requests (
          id BIGSERIAL PRIMARY KEY,
          user_id BIGINT NOT NULL,
          amount NUMERIC(12,2) NOT NULL CHECK (amount >= 100),
          payment_method VARCHAR(50) NOT NULL,
          reference VARCHAR(120) NOT NULL UNIQUE,
          status VARCHAR(30) NOT NULL DEFAULT 'PAYMENT_PENDING',
          provider_reference VARCHAR(150),
          verified_at TIMESTAMPTZ,
          verified_by BIGINT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
      `);

      const reference = createReference("TRB-PAY");

      const result = await pool.query(`
        INSERT INTO credit_recharge_requests (
          user_id,
          amount,
          payment_method,
          reference,
          status
        )
        VALUES ($1,$2,$3,$4,'PAYMENT_PENDING')
        RETURNING
          id,
          amount,
          payment_method,
          reference,
          status,
          created_at
      `, [
        userId,
        amount,
        paymentMethod,
        reference,
      ]);

      const request = result.rows[0];

      res.status(202).json({
        ok: true,
        message:
          "Recharge request created. Credits will be added after payment verification.",
        recharge_id: request.id,
        reference: request.reference,
        amount: Number(request.amount),
        payment_method: request.payment_method,
        status: request.status,
      });

    } catch (error) {
      console.error("POST /api/credits/recharge:", error);

      res.status(500).json({
        ok: false,
        message: error.message || "Credit recharge request failed.",
      });
    }
  });


  /*
   * ADMIN / PAYMENT VERIFICATION
   *
   * Credits are added only after a verified payment event.
   */
  app.post("/api/admin/credit-recharges/:id/verify", authenticateToken, async (req, res) => {
    const client = await pool.connect();

    try {
      const role = String(req.auth?.app_role || "").toLowerCase();

      if (role !== "admin") {
        return res.status(403).json({
          ok: false,
          message: "Administrator authorization required.",
        });
      }

      const rechargeId = Number(req.params.id);

      if (!Number.isInteger(rechargeId) || rechargeId <= 0) {
        return res.status(400).json({
          ok: false,
          message: "Invalid recharge ID.",
        });
      }

      await client.query("BEGIN");

      const rechargeResult = await client.query(`
        SELECT *
        FROM credit_recharge_requests
        WHERE id = $1
        FOR UPDATE
      `, [rechargeId]);

      const recharge = rechargeResult.rows[0];

      if (!recharge) {
        await client.query("ROLLBACK");
        return res.status(404).json({
          ok: false,
          message: "Recharge request not found.",
        });
      }

      if (recharge.status === "VERIFIED") {
        await client.query("ROLLBACK");
        return res.status(409).json({
          ok: false,
          message: "Recharge has already been verified.",
          reference: recharge.reference,
        });
      }

      if (recharge.status !== "PAYMENT_PENDING") {
        await client.query("ROLLBACK");
        return res.status(409).json({
          ok: false,
          message: `Recharge cannot be verified from status ${recharge.status}.`,
        });
      }

      const reference = recharge.reference;

      await addCredits(pool, {
        userId: recharge.user_id,
        amount: Number(recharge.amount),
        type: "ONLINE_RECHARGE",
        reference,
        paymentMethod: recharge.payment_method,
        description: "Verified online credit recharge.",
      });

      await client.query(`
        UPDATE credit_recharge_requests
        SET
          status = 'VERIFIED',
          provider_reference = $2,
          verified_at = NOW(),
          verified_by = $3,
          updated_at = NOW()
        WHERE id = $1
      `, [
        rechargeId,
        String(req.body?.provider_reference || "").trim() || null,
        req.auth.id,
      ]);

      await client.query("COMMIT");

      const balance = await getCreditBalance(
        pool,
        recharge.user_id
      );

      return res.json({
        ok: true,
        message: "Recharge verified and credits added.",
        recharge_id: rechargeId,
        reference,
        amount: Number(recharge.amount),
        balance,
        status: "VERIFIED",
      });

    } catch (error) {
      try {
        await client.query("ROLLBACK");
      } catch {}

      console.error(
        "POST /api/admin/credit-recharges/:id/verify:",
        error
      );

      return res.status(500).json({
        ok: false,
        message: error.message || "Unable to verify recharge.",
      });
    } finally {
      client.release();
    }
  });

  /*
   * DRIVER TRIAL CREDIT
   *
   * Trial = seat capacity x N$5 x 10 trips
   */
  app.post("/api/credits/trial", async (req, res) => {
    try {
      const userId = req.auth?.id;

      if (!userId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const seatCapacity = Number(req.body?.seat_capacity);

      if (
        !Number.isInteger(seatCapacity) ||
        seatCapacity <= 0
      ) {
        return res.status(400).json({
          ok: false,
          message: "Valid seat capacity is required.",
        });
      }

      const existing = await pool.query(
        `
        SELECT trial_credit_granted
        FROM driver_credit_profiles
        WHERE user_id = $1
        `,
        [userId]
      );

      if (existing.rows[0]?.trial_credit_granted) {
        return res.status(409).json({
          ok: false,
          message: "Trial credits have already been granted.",
        });
      }

      const amount =
        seatCapacity *
        CREDIT_PRICE_PER_SEAT *
        TRIAL_TRIPS;

      await pool.query(
        `
        INSERT INTO driver_credit_profiles (
          user_id,
          seat_capacity,
          trial_credit_granted
        )
        VALUES ($1,$2,true)
        ON CONFLICT (user_id)
        DO UPDATE SET
          seat_capacity = EXCLUDED.seat_capacity,
          trial_credit_granted = true,
          updated_at = NOW()
        `,
        [userId, seatCapacity]
      );

      const reference = createReference("TRB-TRIAL");

      await addCredits(pool, {
        userId,
        amount,
        type: "TRIAL_CREDIT",
        reference,
        description:
          `Trial credit: ${seatCapacity} seats � N$5 � 10 trips.`,
      });

      const balance = await getCreditBalance(pool, userId);

      res.status(201).json({
        ok: true,
        amount,
        balance,
        reference,
      });
    } catch (error) {
      console.error("POST /api/credits/trial:", error);

      res.status(500).json({
        ok: false,
        message: error.message || "Unable to issue trial credits.",
      });
    }
  });

  /*
   * CONFIRMED BOOKING DEBIT
   *
   * N$5 per confirmed passenger seat.
   */
  app.post("/api/credits/booking-debit", async (req, res) => {
    try {
      const userId = req.auth?.id;

      if (!userId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const seats = Number(req.body?.seats);
      const bookingId = req.body?.booking_id || null;

      const result = await deductCredits(pool, {
        userId,
        seats,
        bookingId,
      });

      res.json({
        ok: true,
        message: "Booking credit deducted.",
        ...result,
      });
    } catch (error) {
      console.error("POST /api/credits/booking-debit:", error);

      res.status(400).json({
        ok: false,
        message: error.message || "Unable to deduct credits.",
      });
    }
  });

  /*
   * DRIVER CREATES CASH RECHARGE REQUEST
   */
  app.post("/api/agent/cash-request", async (req, res) => {
    try {
      const customerUserId = req.auth?.id;

      if (!customerUserId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const amount = Number(req.body?.amount);
      const agentUserId = req.body?.agent_user_id || null;

      if (!Number.isFinite(amount) || amount < MIN_RECHARGE) {
        return res.status(400).json({
          ok: false,
          message: `Minimum cash recharge is N$${MIN_RECHARGE}.`,
        });
      }

      if (agentUserId) {
        const agentCheck = await pool.query(
          `
          SELECT
            ap.user_id,
            ap.agent_code,
            ap.status
          FROM agent_profiles ap
          WHERE ap.user_id = $1
          `,
          [agentUserId]
        );

        if (
          agentCheck.rows.length === 0 ||
          agentCheck.rows[0].status !== "active"
        ) {
          return res.status(400).json({
            ok: false,
            message: "Selected Treba Agent is not active.",
          });
        }
      }

      const reference = createReference("TRB-CASH");

      const result = await pool.query(
        `
        INSERT INTO agent_cash_requests (
          customer_user_id,
          agent_user_id,
          amount,
          reference
        )
        VALUES ($1,$2,$3,$4)
        RETURNING *
        `,
        [
          customerUserId,
          agentUserId,
          amount,
          reference,
        ]
      );

      res.status(201).json({
        ok: true,
        request: result.rows[0],
        reference,
      });
    } catch (error) {
      console.error("POST /api/agent/cash-request:", error);

      res.status(500).json({
        ok: false,
        message: "Unable to create cash recharge request.",
      });
    }
  });

  /*
   * AGENT ACCEPTS CASH REQUEST
   */
  app.post(
    "/api/agent/cash-request/:id/accept",
    async (req, res) => {
      try {
        const agentUserId = req.auth?.id;

        if (!agentUserId) {
          return res.status(401).json({
            ok: false,
            message: "Authentication required.",
          });
        }

        const agent = await pool.query(
          `
          SELECT
            id,
            agent_code,
            status,
            float_limit
          FROM agent_profiles
          WHERE user_id = $1
          `,
          [agentUserId]
        );

        if (
          agent.rows.length === 0 ||
          agent.rows[0].status !== "active"
        ) {
          return res.status(403).json({
            ok: false,
            message: "Active Treba Agent account required.",
          });
        }

        const requestId = Number(req.params.id);

        const requestResult = await pool.query(
          `
          SELECT *
          FROM agent_cash_requests
          WHERE id = $1
          FOR UPDATE
          `,
          [requestId]
        );

        if (requestResult.rows.length === 0) {
          return res.status(404).json({
            ok: false,
            message: "Cash request not found.",
          });
        }

        const request = requestResult.rows[0];

        if (
          request.status !== "WAITING_FOR_AGENT" &&
          request.status !== "PENDING"
        ) {
          return res.status(409).json({
            ok: false,
            message: "This cash request is no longer available.",
          });
        }

        const liabilityResult = await pool.query(
          `
          SELECT COALESCE(SUM(amount),0) AS outstanding
          FROM agent_liabilities
          WHERE agent_user_id = $1
            AND status = 'OUTSTANDING'
          `,
          [agentUserId]
        );

        const outstanding = Number(
          liabilityResult.rows[0]?.outstanding || 0
        );

        const limit = Number(agent.rows[0].float_limit);

        if (outstanding + Number(request.amount) > limit) {
          return res.status(409).json({
            ok: false,
            message:
              "Agent cash limit reached. Please settle outstanding cash before accepting more.",
          });
        }

        await pool.query(
          `
          UPDATE agent_cash_requests
          SET
            agent_user_id = $1,
            status = 'AGENT_ACCEPTED',
            updated_at = NOW()
          WHERE id = $2
          `,
          [agentUserId, requestId]
        );

        res.json({
          ok: true,
          message: "Cash request accepted.",
          reference: request.reference,
          agentCode: agent.rows[0].agent_code,
        });
      } catch (error) {
        console.error(
          "POST /api/agent/cash-request/:id/accept:",
          error
        );

        res.status(500).json({
          ok: false,
          message: "Unable to accept cash request.",
        });
      }
    }
  );

  /*
   * AGENT CONFIRMS CASH RECEIVED
   */
  app.post(
    "/api/agent/cash-request/:id/agent-confirm",
    async (req, res) => {
      try {
        const agentUserId = req.auth?.id;

        if (!agentUserId) {
          return res.status(401).json({
            ok: false,
            message: "Authentication required.",
          });
        }

        const requestId = Number(req.params.id);

        const requestResult = await pool.query(
          `
          SELECT *
          FROM agent_cash_requests
          WHERE id = $1
            AND agent_user_id = $2
          `,
          [requestId, agentUserId]
        );

        if (requestResult.rows.length === 0) {
          return res.status(404).json({
            ok: false,
            message: "Cash request not found.",
          });
        }

        await pool.query(
          `
          UPDATE agent_cash_requests
          SET
            agent_confirmed = true,
            updated_at = NOW()
          WHERE id = $1
          `,
          [requestId]
        );

        const updated = await pool.query(
          `
          SELECT *
          FROM agent_cash_requests
          WHERE id = $1
          `,
          [requestId]
        );

        const request = updated.rows[0];

        if (
          request.agent_confirmed &&
          request.customer_confirmed &&
          request.status !== "COMPLETED"
        ) {
          const reference = request.reference;

          await addCredits(pool, {
            userId: request.customer_user_id,
            amount: Number(request.amount),
            type: "AGENT_CASH_RECHARGE",
            reference,
            paymentMethod: "cash",
            description: `Cash recharge through Treba Agent.`,
            createdBy: agentUserId,
          });

          await pool.query(
            `
            UPDATE agent_cash_requests
            SET
              status = 'COMPLETED',
              updated_at = NOW()
            WHERE id = $1
            `,
            [requestId]
          );

          await pool.query(
            `
            INSERT INTO agent_liabilities (
              agent_user_id,
              cash_request_id,
              amount
            )
            VALUES ($1,$2,$3)
            ON CONFLICT (cash_request_id) DO NOTHING
            `,
            [
              agentUserId,
              requestId,
              request.amount,
            ]
          );
        }

        res.json({
          ok: true,
          message:
            request.customer_confirmed
              ? "Cash transaction completed and credits loaded."
              : "Agent cash receipt recorded. Waiting for customer confirmation.",
        });
      } catch (error) {
        console.error(
          "POST /api/agent/cash-request/:id/agent-confirm:",
          error
        );

        res.status(500).json({
          ok: false,
          message: error.message || "Unable to confirm cash.",
        });
      }
    }
  );

  /*
   * CUSTOMER CONFIRMS CASH HANDED OVER
   */
  app.post(
    "/api/agent/cash-request/:id/customer-confirm",
    async (req, res) => {
      try {
        const customerUserId = req.auth?.id;

        if (!customerUserId) {
          return res.status(401).json({
            ok: false,
            message: "Authentication required.",
          });
        }

        const requestId = Number(req.params.id);

        const requestResult = await pool.query(
          `
          SELECT *
          FROM agent_cash_requests
          WHERE id = $1
            AND customer_user_id = $2
          `,
          [requestId, customerUserId]
        );

        if (requestResult.rows.length === 0) {
          return res.status(404).json({
            ok: false,
            message: "Cash request not found.",
          });
        }

        await pool.query(
          `
          UPDATE agent_cash_requests
          SET
            customer_confirmed = true,
            updated_at = NOW()
          WHERE id = $1
          `,
          [requestId]
        );

        const updated = await pool.query(
          `
          SELECT *
          FROM agent_cash_requests
          WHERE id = $1
          `,
          [requestId]
        );

        const request = updated.rows[0];

        if (
          request.agent_confirmed &&
          request.customer_confirmed &&
          request.status !== "COMPLETED"
        ) {
          const reference = request.reference;

          await addCredits(pool, {
            userId: request.customer_user_id,
            amount: Number(request.amount),
            type: "AGENT_CASH_RECHARGE",
            reference,
            paymentMethod: "cash",
            description: "Cash recharge through Treba Agent.",
            createdBy: request.agent_user_id,
          });

          await pool.query(
            `
            UPDATE agent_cash_requests
            SET
              status = 'COMPLETED',
              updated_at = NOW()
            WHERE id = $1
            `,
            [requestId]
          );

          await pool.query(
            `
            INSERT INTO agent_liabilities (
              agent_user_id,
              cash_request_id,
              amount
            )
            VALUES ($1,$2,$3)
            ON CONFLICT (cash_request_id) DO NOTHING
            `,
            [
              request.agent_user_id,
              requestId,
              request.amount,
            ]
          );
        }

        const balance = await getCreditBalance(
          pool,
          customerUserId
        );

        res.json({
          ok: true,
          message:
            request.agent_confirmed
              ? "Cash transaction completed and credits loaded."
              : "Customer confirmation recorded. Waiting for agent.",
          balance,
        });
      } catch (error) {
        console.error(
          "POST /api/agent/cash-request/:id/customer-confirm:",
          error
        );

        res.status(500).json({
          ok: false,
          message: error.message || "Unable to confirm transaction.",
        });
      }
    }
  );

  /*
   * AGENT DASHBOARD
   */
  app.get("/api/agent/dashboard", async (req, res) => {
    try {
      const agentUserId = req.auth?.id;

      if (!agentUserId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const agent = await pool.query(
        `
        SELECT
          ap.*,
          u.full_name,
          u.phone
        FROM agent_profiles ap
        JOIN users u
          ON u.id = ap.user_id
        WHERE ap.user_id = $1
        `,
        [agentUserId]
      );

      if (agent.rows.length === 0) {
        return res.status(403).json({
          ok: false,
          message: "Treba Agent account required.",
        });
      }

      const liability = await pool.query(
        `
        SELECT COALESCE(SUM(amount),0) AS outstanding
        FROM agent_liabilities
        WHERE agent_user_id = $1
          AND status = 'OUTSTANDING'
        `,
        [agentUserId]
      );

      const commission = await pool.query(
        `
        SELECT
          COALESCE(
            (
              SELECT SUM(commission_amount)
              FROM agent_commission_transactions
              WHERE agent_user_id = $1
            ),
            0
          ) AS earned,

          COALESCE(
            (
              SELECT balance
              FROM agent_commission_wallets
              WHERE agent_user_id = $1
            ),
            0
          ) AS wallet
        `,
        [agentUserId]
      );

      const requests = await pool.query(
        `
        SELECT *
        FROM agent_cash_requests
        WHERE agent_user_id = $1
           OR (
             agent_user_id IS NULL
             AND status = 'WAITING_FOR_AGENT'
           )
        ORDER BY created_at DESC
        LIMIT 50
        `,
        [agentUserId]
      );

      const transactions = await pool.query(
        `
        SELECT
          acr.id,
          acr.amount,
          acr.reference,
          acr.status,
          acr.created_at,
          u.full_name AS customer_name,
          u.phone AS customer_phone
        FROM agent_cash_requests acr
        JOIN users u
          ON u.id = acr.customer_user_id
        WHERE acr.agent_user_id = $1
        ORDER BY acr.created_at DESC
        LIMIT 50
        `,
        [agentUserId]
      );

      const outstanding = Number(
        liability.rows[0]?.outstanding || 0
      );

      const floatLimit = Number(
        agent.rows[0].float_limit
      );

      res.json({
        ok: true,
        agent: {
          id: agent.rows[0].id,
          code: agent.rows[0].agent_code,
          status: agent.rows[0].status,
          name: agent.rows[0].full_name,
          phone: agent.rows[0].phone,
        },
        cash: {
          outstanding,
          floatLimit,
          availableFloat: Math.max(
            0,
            floatLimit - outstanding
          ),
          warningPercent:
            floatLimit > 0
              ? (outstanding / floatLimit) * 100
              : 100,
        },
        commission: {
          earned: Number(
            commission.rows[0]?.earned || 0
          ),
          wallet: Number(
            commission.rows[0]?.wallet || 0
          ),
        },
        pendingRequests: requests.rows,
        transactions: transactions.rows,
      });
    } catch (error) {
      console.error(
        "GET /api/agent/dashboard:",
        error
      );

      res.status(500).json({
        ok: false,
        message: "Unable to load agent dashboard.",
      });
    }
  });

  /*
   * AGENT SETTLEMENT
   */
  app.post("/api/agent/settlement", async (req, res) => {
    try {
      const agentUserId = req.auth?.id;

      if (!agentUserId) {
        return res.status(401).json({
          ok: false,
          message: "Authentication required.",
        });
      }

      const amount = Number(req.body?.amount);
      const paymentReference =
        String(req.body?.payment_reference || "").trim();

      if (!Number.isFinite(amount) || amount <= 0) {
        return res.status(400).json({
          ok: false,
          message: "Invalid settlement amount.",
        });
      }

      const agent = await pool.query(
        `
        SELECT id
        FROM agent_profiles
        WHERE user_id = $1
          AND status = 'active'
        `,
        [agentUserId]
      );

      if (agent.rows.length === 0) {
        return res.status(403).json({
          ok: false,
          message: "Active Treba Agent account required.",
        });
      }

      const liability = await pool.query(
        `
        SELECT COALESCE(SUM(amount),0) AS outstanding
        FROM agent_liabilities
        WHERE agent_user_id = $1
          AND status = 'OUTSTANDING'
        `,
        [agentUserId]
      );

      const outstanding = Number(
        liability.rows[0]?.outstanding || 0
      );

      if (amount > outstanding) {
        return res.status(400).json({
          ok: false,
          message:
            "Settlement cannot exceed outstanding cash liability.",
        });
      }

      const reference = createReference("SET");

      const result = await pool.query(
        `
        INSERT INTO agent_settlements (
          agent_user_id,
          amount,
          reference,
          payment_reference
        )
        VALUES ($1,$2,$3,$4)
        RETURNING *
        `,
        [
          agentUserId,
          amount,
          reference,
          paymentReference || null,
        ]
      );

      res.status(201).json({
        ok: true,
        settlement: result.rows[0],
        message:
          "Settlement recorded as payment pending. Treba must verify receipt before marking it paid.",
      });
    } catch (error) {
      console.error(
        "POST /api/agent/settlement:",
        error
      );

      res.status(500).json({
        ok: false,
        message: "Unable to create settlement.",
      });
    }
  });

  /*
   * ADMIN / PAYMENT SERVICE VERIFICATION
   *
   * This endpoint intentionally requires an existing
   * authenticated admin identity.
   *
   * Replace req.auth.app_role with your final admin role
   * if your application uses another field.
   */
  app.post(
    "/api/agent/settlement/:id/verify",
    async (req, res) => {
      try {
        const role = req.auth?.app_role;

        if (role !== "admin") {
          return res.status(403).json({
            ok: false,
            message: "Administrator authorization required.",
          });
        }

        const settlementId = Number(req.params.id);

        const settlementResult = await pool.query(
          `
          SELECT *
          FROM agent_settlements
          WHERE id = $1
            AND status = 'PAYMENT_PENDING'
          `,
          [settlementId]
        );

        if (settlementResult.rows.length === 0) {
          return res.status(404).json({
            ok: false,
            message: "Pending settlement not found.",
          });
        }

        const settlement =
          settlementResult.rows[0];

        await pool.query("BEGIN");

        try {
          await pool.query(
            `
            UPDATE agent_settlements
            SET
              status = 'PAID',
              verified_at = NOW()
            WHERE id = $1
            `,
            [settlementId]
          );

          let remaining =
            Number(settlement.amount);

          const liabilities = await pool.query(
            `
            SELECT id, amount
            FROM agent_liabilities
            WHERE agent_user_id = $1
              AND status = 'OUTSTANDING'
            ORDER BY created_at ASC
            FOR UPDATE
            `,
            [settlement.agent_user_id]
          );

          for (const item of liabilities.rows) {
            if (remaining <= 0) break;

            const itemAmount = Number(item.amount);

            if (remaining >= itemAmount) {
              await pool.query(
                `
                UPDATE agent_liabilities
                SET
                  status = 'SETTLED',
                  settled_at = NOW()
                WHERE id = $1
                `,
                [item.id]
              );

              remaining -= itemAmount;
            } else {
              /*
               * Partial settlement support.
               */
              await pool.query(
                `
                UPDATE agent_liabilities
                SET
                  amount = amount - $1
                WHERE id = $2
                `,
                [remaining, item.id]
              );

              remaining = 0;
            }
          }

          /*
           * Commission = 10% of verified settlement.
           */
          const commissionAmount =
            Number(settlement.amount) *
            AGENT_COMMISSION_RATE;

          await pool.query(
            `
            INSERT INTO agent_commission_wallets (
              agent_user_id,
              balance
            )
            VALUES ($1,$2)
            ON CONFLICT (agent_user_id)
            DO UPDATE SET
              balance =
                agent_commission_wallets.balance + EXCLUDED.balance,
              updated_at = NOW()
            `,
            [
              settlement.agent_user_id,
              commissionAmount,
            ]
          );

          await pool.query(
            `
            INSERT INTO agent_commission_transactions (
              agent_user_id,
              settlement_id,
              gross_settlement,
              commission_rate,
              commission_amount
            )
            VALUES ($1,$2,$3,$4,$5)
            ON CONFLICT (settlement_id) DO NOTHING
            `,
            [
              settlement.agent_user_id,
              settlementId,
              settlement.amount,
              AGENT_COMMISSION_RATE,
              commissionAmount,
            ]
          );

          await pool.query("COMMIT");

          res.json({
            ok: true,
            message: "Settlement verified.",
            commission: commissionAmount,
          });
        } catch (error) {
          await pool.query("ROLLBACK");
          throw error;
        }
      } catch (error) {
        console.error(
          "POST /api/agent/settlement/:id/verify:",
          error
        );

        res.status(500).json({
          ok: false,
          message:
            error.message || "Settlement verification failed.",
        });
      }
    }
  );

  /*
   * CREATE AGENT PROFILE
   *
   * Intended for admin-controlled agent provisioning.
   */
  app.post("/api/admin/agents", async (req, res) => {
    try {
      /*
       * ONLY TREBA ADMINISTRATORS MAY CREATE AGENT ACCOUNTS.
       *
       * Agents can never create another agent.
       * Drivers/passengers cannot create agent accounts.
       */
      const authenticatedRole =
        String(req.auth?.app_role || "").toLowerCase();

      const authenticatedSystemRole =
        String(req.auth?.role || "").toLowerCase();

      const isAdmin =
        authenticatedRole === "admin" ||
        authenticatedSystemRole === "admin";

      if (!isAdmin) {
        return res.status(403).json({
          ok: false,
          message:
            "Only a Treba Administrator may create Agent accounts.",
        });
      }

      const userId = Number(req.body?.user_id);

      if (!Number.isInteger(userId)) {
        return res.status(400).json({
          ok: false,
          message: "Valid user_id is required.",
        });
      }

      const existing = await pool.query(
        `
        SELECT id
        FROM agent_profiles
        WHERE user_id = $1
        `,
        [userId]
      );

      if (existing.rows.length > 0) {
        return res.status(409).json({
          ok: false,
          message: "User is already a Treba Agent.",
        });
      }

      const next = await pool.query(
        `
        SELECT COUNT(*)::integer + 1 AS number
        FROM agent_profiles
        `
      );

      const number = Number(
        next.rows[0]?.number || 1
      );

      const agentCode =
        `AGT-${String(number).padStart(5, "0")}`;

      const result = await pool.query(
        `
        INSERT INTO agent_profiles (
          user_id,
          agent_code,
          float_limit
        )
        VALUES ($1,$2,$3)
        RETURNING *
        `,
        [
          userId,
          agentCode,
          DEFAULT_AGENT_FLOAT_LIMIT,
        ]
      );

      await pool.query(
        `
        INSERT INTO agent_commission_wallets (
          agent_user_id
        )
        VALUES ($1)
        ON CONFLICT (agent_user_id) DO NOTHING
        `,
        [userId]
      );

      res.status(201).json({
        ok: true,
        agent: result.rows[0],
      });
    } catch (error) {
      console.error(
        "POST /api/admin/agents:",
        error
      );

      res.status(500).json({
        ok: false,
        message: "Unable to create agent.",
      });
    }
  });
}

module.exports = {
  registerCreditAgentRoutes,
  ensureCreditAgentSchema,
  CREDIT_PRICE_PER_SEAT,
  MIN_RECHARGE,
  TRIAL_TRIPS,
  AGENT_COMMISSION_RATE,
};


