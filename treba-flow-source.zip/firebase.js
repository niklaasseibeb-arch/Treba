import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyC1gGh-o4Uera5pyVHkBWCxgo1pJskES8Y",
  authDomain: "treba-294c0.firebaseapp.com",
  projectId: "treba-294c0",
  storageBucket: "treba-294c0.firebasestorage.app",
  messagingSenderId: "617046294993",
  appId: "1:617046294993:web:dbee25bb2bf03e5576a0f0"
};

const app = initializeApp(firebaseConfig);

export const firebaseAuth = getAuth(app);

export default app;