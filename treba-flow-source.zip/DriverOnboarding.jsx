﻿import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Car,
  ClipboardCheck,
  FileText,
  MapPin,
  UserRound,
  ShieldCheck,
  AlertCircle,
} from "lucide-react";

const STEPS = [
  { id: 1, label: "Driver Info", icon: UserRound },
  { id: 2, label: "Vehicle Info", icon: Car },
  { id: 3, label: "Route Setup", icon: MapPin },
  { id: 4, label: "Approval", icon: ClipboardCheck },
];

function daysUntil(dateString) {
  if (!dateString) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const expiry = new Date(`${dateString}T00:00:00`);
  expiry.setHours(0, 0, 0, 0);

  return Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
}

/*
 * TREBA AUTOMATIC APPROVAL RULE
 *
 * Approval requires:
 *
 * Driver licence expiry:
 *     more than 30 days remaining
 *
 * Vehicle licence expiry:
 *     more than 30 days remaining
 *
 * AND
 *
 * All checklist items are confirmed
 *
 * AND
 *
 * Truthful declaration is confirmed
 */
function evaluateApproval({
  driverLicenseExpiry,
  vehicleLicenseExpiry,
  checklist,
  declaration,
}) {
  const driverDays = daysUntil(driverLicenseExpiry);
  const vehicleDays = daysUntil(vehicleLicenseExpiry);

  const driverExpiryValid =
    driverDays !== null &&
    driverDays > 30;

  const vehicleExpiryValid =
    vehicleDays !== null &&
    vehicleDays > 30;

  const checklistComplete =
    checklist.driverLicense &&
    checklist.vehicleLicense &&
    checklist.roadworthy &&
    checklist.fitnessCertificate &&
    checklist.publicRoadCarrierPermit;

  const declarationValid = declaration === true;

  const approved =
    driverExpiryValid &&
    vehicleExpiryValid &&
    checklistComplete &&
    declarationValid;

  return {
    approved,
    driverDays,
    vehicleDays,
    driverExpiryValid,
    vehicleExpiryValid,
    checklistComplete,
    declarationValid,
  };
}

export default function DriverOnboarding() {
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  const [driver, setDriver] = useState({
    idNumber: "",
    drivingLicenseNumber: "",
    drivingLicenseExpiry: "",
    publicDrivingPermit: "",
  });

  const [vehicle, setVehicle] = useState({
    make: "",
    type: "",
    model: "",
    seatCapacity: "",
    registrationNumber: "",
    licenseExpiry: "",
  });

  const [route, setRoute] = useState({
    fromTown: "",
    toTown: "",
    frequency: "",
    originTown: "",
    tripType: "",
    pickupPoint: "",
    dropoffPoint: "",
  });

  const [checklist, setChecklist] = useState({
    driverLicense: false,
    vehicleLicense: false,
    roadworthy: false,
    fitnessCertificate: false,
    publicRoadCarrierPermit: false,
  });

  const [declaration, setDeclaration] = useState(false);

  const approval = useMemo(
    () =>
      evaluateApproval({
        driverLicenseExpiry: driver.drivingLicenseExpiry,
        vehicleLicenseExpiry: vehicle.licenseExpiry,
        checklist,
        declaration,
      }),
    [
      driver.drivingLicenseExpiry,
      vehicle.licenseExpiry,
      checklist,
      declaration,
    ]
  );

  function updateDriver(field, value) {
    setDriver((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  function updateVehicle(field, value) {
    setVehicle((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  function updateRoute(field, value) {
    setRoute((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  function updateChecklist(field) {
    setChecklist((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  }

  function nextStep() {
    setStep((prev) => Math.min(prev + 1, 4));
  }

  function previousStep() {
    setStep((prev) => Math.max(prev - 1, 1));
  }

  function submitOnboarding() {
    setSubmitted(true);

    if (!approval.approved) {
      return;
    }

    /*
     * The application has passed all automatic rules.
     *
     * Store the following data in your backend when the
     * driver onboarding API is connected:
     *
     * driver
     * vehicle
     * route
     * checklist
     * declaration
     * approval_status = "APPROVED"
     */

    navigate("/driver/dashboard");
  }

  const inputClass =
    "mt-1 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";

  const labelClass =
    "text-sm font-medium text-foreground";

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">

        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">
            Driver Registration
          </h1>

          <p className="mt-2 text-muted-foreground">
            Complete your driver, vehicle and route information
            to start driving with Treba.
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
          {STEPS.map((item) => {
            const Icon = item.icon;
            const active = step === item.id;
            const complete = step > item.id;

            return (
              <div
                key={item.id}
                className={`rounded-xl border p-4 ${
                  active
                    ? "border-primary bg-primary/10"
                    : complete
                    ? "border-primary/30 bg-card"
                    : "border-border bg-card"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-full ${
                      active || complete
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {complete ? (
                      <CheckCircle2 className="h-5 w-5" />
                    ) : (
                      <Icon className="h-5 w-5" />
                    )}
                  </div>

                  <div>
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                      Step {item.id}
                    </p>
                    <p className="text-sm font-semibold">
                      {item.label}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Main Form */}
        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">

          {/* STEP 1 */}
          {step === 1 && (
            <section>
              <div className="mb-6">
                <h2 className="text-2xl font-bold">
                  Driver Information
                </h2>

                <p className="mt-1 text-sm text-muted-foreground">
                  Enter your identification and driving information.
                </p>
              </div>

              <div className="grid gap-5 md:grid-cols-2">

                <div>
                  <label className={labelClass}>
                    Driver ID Number
                  </label>

                  <input
                    type="text"
                    value={driver.idNumber}
                    onChange={(e) =>
                      updateDriver("idNumber", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Enter ID number"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Driving License Number
                  </label>

                  <input
                    type="text"
                    value={driver.drivingLicenseNumber}
                    onChange={(e) =>
                      updateDriver(
                        "drivingLicenseNumber",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="Enter driving license number"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Driving License Expiry Date
                  </label>

                  <input
                    type="date"
                    value={driver.drivingLicenseExpiry}
                    onChange={(e) =>
                      updateDriver(
                        "drivingLicenseExpiry",
                        e.target.value
                      )
                    }
                    className={inputClass}
                  />

                  {driver.drivingLicenseExpiry && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      {approval.driverDays < 0
                        ? "License has expired."
                        : `${approval.driverDays} day(s) remaining.`}
                    </p>
                  )}
                </div>

                <div>
                  <label className={labelClass}>
                    Public Driving Permit
                  </label>

                  <select
                    value={driver.publicDrivingPermit}
                    onChange={(e) =>
                      updateDriver(
                        "publicDrivingPermit",
                        e.target.value
                      )
                    }
                    className={inputClass}
                  >
                    <option value="">
                      Select option
                    </option>

                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>

              </div>
            </section>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <section>
              <div className="mb-6">
                <h2 className="text-2xl font-bold">
                  Vehicle Information
                </h2>

                <p className="mt-1 text-sm text-muted-foreground">
                  Provide the vehicle information that will be
                  used for Treba trips.
                </p>
              </div>

              <div className="grid gap-5 md:grid-cols-2">

                <div>
                  <label className={labelClass}>
                    Vehicle Make
                  </label>

                  <input
                    type="text"
                    value={vehicle.make}
                    onChange={(e) =>
                      updateVehicle("make", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Toyota"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Vehicle Type
                  </label>

                  <input
                    type="text"
                    value={vehicle.type}
                    onChange={(e) =>
                      updateVehicle("type", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Sedan / SUV / Minibus"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Vehicle Model
                  </label>

                  <input
                    type="text"
                    value={vehicle.model}
                    onChange={(e) =>
                      updateVehicle("model", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Hilux"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Vehicle Seat Capacity
                  </label>

                  <input
                    type="number"
                    min="1"
                    value={vehicle.seatCapacity}
                    onChange={(e) =>
                      updateVehicle(
                        "seatCapacity",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="4"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Vehicle Registration Number
                  </label>

                  <input
                    type="text"
                    value={vehicle.registrationNumber}
                    onChange={(e) =>
                      updateVehicle(
                        "registrationNumber",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="N12345W"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Vehicle License Expiry Date
                  </label>

                  <input
                    type="date"
                    value={vehicle.licenseExpiry}
                    onChange={(e) =>
                      updateVehicle(
                        "licenseExpiry",
                        e.target.value
                      )
                    }
                    className={inputClass}
                  />

                  {vehicle.licenseExpiry && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      {approval.vehicleDays < 0
                        ? "Vehicle license has expired."
                        : `${approval.vehicleDays} day(s) remaining.`}
                    </p>
                  )}
                </div>

              </div>
            </section>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <section>
              <div className="mb-6">
                <h2 className="text-2xl font-bold">
                  Route Setup
                </h2>

                <p className="mt-1 text-sm text-muted-foreground">
                  Tell Treba which towns and pickup/drop-off
                  points you serve.
                </p>
              </div>

              <div className="grid gap-5 md:grid-cols-2">

                <div>
                  <label className={labelClass}>
                    From Town
                  </label>

                  <input
                    type="text"
                    value={route.fromTown}
                    onChange={(e) =>
                      updateRoute("fromTown", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Windhoek"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    To Town
                  </label>

                  <input
                    type="text"
                    value={route.toTown}
                    onChange={(e) =>
                      updateRoute("toTown", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Karibib"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    Frequency
                  </label>

                  <select
                    value={route.frequency}
                    onChange={(e) =>
                      updateRoute("frequency", e.target.value)
                    }
                    className={inputClass}
                  >
                    <option value="">
                      Select frequency
                    </option>

                    <option value="every_day">
                      Every Day
                    </option>

                    <option value="monday_friday">
                      Monday – Friday
                    </option>
                  </select>
                </div>

                <div>
                  <label className={labelClass}>
                    Origin Town
                  </label>

                  <input
                    type="text"
                    value={route.originTown}
                    onChange={(e) =>
                      updateRoute("originTown", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Windhoek"
                  />
                </div>

                <div>
                  <label className={labelClass}>
                    One Way or Return
                  </label>

                  <select
                    value={route.tripType}
                    onChange={(e) =>
                      updateRoute("tripType", e.target.value)
                    }
                    className={inputClass}
                  >
                    <option value="">
                      Select trip type
                    </option>

                    <option value="one_way">
                      One Way
                    </option>

                    <option value="return">
                      Return
                    </option>
                  </select>
                </div>

                <div>
                  <label className={labelClass}>
                    Standard Pickup Point
                  </label>

                  <input
                    type="text"
                    value={route.pickupPoint}
                    onChange={(e) =>
                      updateRoute(
                        "pickupPoint",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="Town pickup point"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className={labelClass}>
                    Standard Drop-off Point
                  </label>

                  <input
                    type="text"
                    value={route.dropoffPoint}
                    onChange={(e) =>
                      updateRoute(
                        "dropoffPoint",
                        e.target.value
                      )
                    }
                    className={inputClass}
                    placeholder="Town drop-off point"
                  />
                </div>

              </div>
            </section>
          )}

          {/* STEP 4 */}
          {step === 4 && (
            <section>
              <div className="mb-6">
                <h2 className="text-2xl font-bold">
                  Automatic Approval
                </h2>

                <p className="mt-1 text-sm text-muted-foreground">
                  Confirm each requirement before Treba
                  evaluates your application.
                </p>
              </div>

              <div className="space-y-4">

                <label className="flex cursor-pointer gap-3 rounded-xl border border-border p-4">
                  <input
                    type="checkbox"
                    checked={checklist.driverLicense}
                    onChange={() =>
                      updateChecklist("driverLicense")
                    }
                    className="mt-1 h-5 w-5"
                  />

                  <span className="text-sm">
                    My driver's license does not expire within the next
                    30 days.
                  </span>
                </label>

                <label className="flex cursor-pointer gap-3 rounded-xl border border-border p-4">
                  <input
                    type="checkbox"
                    checked={checklist.vehicleLicense}
                    onChange={() =>
                      updateChecklist("vehicleLicense")
                    }
                    className="mt-1 h-5 w-5"
                  />

                  <span className="text-sm">
                    The vehicle license disc expires in less
                    than 30 days and has not expired.
                  </span>
                </label>

                <label className="flex cursor-pointer gap-3 rounded-xl border border-border p-4">
                  <input
                    type="checkbox"
                    checked={checklist.roadworthy}
                    onChange={() =>
                      updateChecklist("roadworthy")
                    }
                    className="mt-1 h-5 w-5"
                  />

                  <span className="text-sm">
                    The vehicle is roadworthy.
                  </span>
                </label>

                <label className="flex cursor-pointer gap-3 rounded-xl border border-border p-4">
                  <input
                    type="checkbox"
                    checked={checklist.fitnessCertificate}
                    onChange={() =>
                      updateChecklist("fitnessCertificate")
                    }
                    className="mt-1 h-5 w-5"
                  />

                  <span className="text-sm">
                    The vehicle has a valid fitness certificate.
                  </span>
                </label>

                <label className="flex cursor-pointer gap-3 rounded-xl border border-border p-4">
                  <input
                    type="checkbox"
                    checked={checklist.publicRoadCarrierPermit}
                    onChange={() =>
                      updateChecklist(
                        "publicRoadCarrierPermit"
                      )
                    }
                    className="mt-1 h-5 w-5"
                  />

                  <span className="text-sm">
                    I have a valid Public Road Carrier Permit.
                  </span>
                </label>

              </div>

              {/* Declaration */}
              <div className="mt-8 rounded-2xl border border-primary/20 bg-primary/5 p-5">
                <div className="flex gap-3">
                  <FileText className="mt-1 h-5 w-5 shrink-0 text-primary" />

                  <div>
                    <h3 className="font-semibold">
                      Declaration / Affirmation
                    </h3>

                    <p className="mt-2 text-sm leading-6 text-muted-foreground">
                      I declare and affirm that all information
                      I have provided to Treba is correct,
                      complete and truthful.
                    </p>

                    <label className="mt-4 flex cursor-pointer gap-3">
                      <input
                        type="checkbox"
                        checked={declaration}
                        onChange={() =>
                          setDeclaration((prev) => !prev)
                        }
                        className="mt-1 h-5 w-5"
                      />

                      <span className="text-sm font-medium">
                        I confirm that the information provided
                        is correct and truthful.
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Approval Result */}
              <div className="mt-8">

                {approval.approved ? (
                  <div className="rounded-2xl border border-green-500/30 bg-green-500/10 p-5">
                    <div className="flex gap-3">
                      <CheckCircle2 className="h-6 w-6 shrink-0 text-green-600" />

                      <div>
                        <h3 className="font-semibold text-green-700">
                          Automatic Approval Passed
                        </h3>

                        <p className="mt-1 text-sm text-muted-foreground">
                          All Treba approval requirements have
                          been satisfied.
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5">
                    <div className="flex gap-3">
                      <AlertCircle className="h-6 w-6 shrink-0 text-amber-600" />

                      <div>
                        <h3 className="font-semibold">
                          Approval Requirements
                        </h3>

                        <div className="mt-3 space-y-2 text-sm">

                          <p>
                            Driver license:
                            {" "}
                            {approval.driverExpiryValid
                              ? "✓ Pass"
                              : "✗ Must have more than 30 days remaining and not expired"}
                          </p>

                          <p>
                            Vehicle license:
                            {" "}
                            {approval.vehicleExpiryValid
                              ? "✓ Pass"
                              : "✗ Must have more than 30 days remaining and not expired"}
                          </p>

                          <p>
                            Checklist:
                            {" "}
                            {approval.checklistComplete
                              ? "✓ Complete"
                              : "✗ All items must be checked"}
                          </p>

                          <p>
                            Declaration:
                            {" "}
                            {approval.declarationValid
                              ? "✓ Confirmed"
                              : "✗ Confirmation required"}
                          </p>

                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {submitted && !approval.approved && (
                <div className="mt-4 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
                  Your application cannot be automatically
                  approved yet. Please correct the outstanding
                  requirements.
                </div>
              )}

            </section>
          )}

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-between border-t border-border pt-6">

            <button
              type="button"
              onClick={previousStep}
              disabled={step === 1}
              className="inline-flex items-center gap-2 rounded-xl border border-border px-5 py-3 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </button>

            {step < 4 ? (
              <button
                type="button"
                onClick={nextStep}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
              >
                Continue
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={submitOnboarding}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
              >
                <ShieldCheck className="h-4 w-4" />
                Complete Registration
              </button>
            )}

          </div>

        </div>
      </div>
    </div>
  );
}


