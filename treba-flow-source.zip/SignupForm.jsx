﻿import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  RecaptchaVerifier,
  signInWithPhoneNumber,
} from "firebase/auth";
import { firebaseAuth } from "@/firebase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Loader2,
  Lock,
  Mail,
  UserPlus,
  ShieldCheck,
  Car,
  Phone,
} from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";

const normalizeNamibiaPhone = (value) => {
  const cleaned = value.replace(/[^\d+]/g, "");

  if (cleaned.startsWith("+264")) return cleaned;
  if (cleaned.startsWith("264")) return `+${cleaned}`;
  if (cleaned.startsWith("0")) return `+264${cleaned.substring(1)}`;

  return cleaned;
};

export default function SignupForm({ embedded = false }) {
  const [role, setRole] = useState("passenger");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [mobileOtp, setMobileOtp] = useState("");
  const [confirmationResult, setConfirmationResult] = useState(null);

  const [step, setStep] = useState("account");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const recaptchaVerifierRef = useRef(null);

  const storeAuthentication = (token, user) => {
    if (!token) {
      throw new Error("No authentication token was returned.");
    }

    if (!user?.id) {
      throw new Error("No authenticated user was returned.");
    }

    localStorage.setItem("treba_token", token);
    localStorage.setItem("treba_user", JSON.stringify(user));
  };

  useEffect(() => {
    return () => {
      if (recaptchaVerifierRef.current) {
        try {
          recaptchaVerifierRef.current.clear();
        } catch {
          // Ignore cleanup errors.
        }
        recaptchaVerifierRef.current = null;
      }
    };
  }, []);

  const handleAccountSubmit = async (event) => {
    event.preventDefault();
    setError("");

    if (!fullName.trim()) {
      setError("Full name is required.");
      return;
    }

    if (!phone.trim()) {
      setError("Mobile number is required.");
      return;
    }

    if (!password) {
      setError("Password is required.");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    const firebasePhone = normalizeNamibiaPhone(phone);

    if (!firebasePhone.startsWith("+264") || firebasePhone.length < 12) {
      setError("Please enter a valid Namibian mobile number.");
      return;
    }

    setLoading(true);

    try {
      console.log("=================================");
      console.log("TREBA REGISTRATION START");
      console.log("Role:", role);
      console.log("Phone:", firebasePhone);
      console.log("=================================");

      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          app_role: role,
          full_name: fullName.trim(),
          phone: firebasePhone,
          password,
        }),
      });

      const data = await response.json();

      console.log("TREBA REGISTER RESULT:", data);

      if (!response.ok) {
        throw new Error(
          data?.message ||
          data?.error ||
          "Failed to create account."
        );
      }

      if (!data?.token || !data?.user) {
        throw new Error(
          "Account was created, but no authentication session was returned."
        );
      }

      storeAuthentication(data.token, data.user);

      if (role === "passenger") {
        setStep("passengerOtp");

        await new Promise((resolve) => setTimeout(resolve, 150));

        if (!recaptchaVerifierRef.current) {
          recaptchaVerifierRef.current = new RecaptchaVerifier(
            firebaseAuth,
            "recaptcha-container",
            {
              size: "normal",
              callback: () => {
                console.log("Firebase reCAPTCHA solved.");
              },
              "expired-callback": () => {
                console.log("Firebase reCAPTCHA expired.");
                setError(
                  "The security check expired. Please try again."
                );
              },
            }
          );
        }

        console.log("TREBA FIREBASE: Sending SMS OTP...");

        const result = await signInWithPhoneNumber(
          firebaseAuth,
          firebasePhone,
          recaptchaVerifierRef.current
        );

        setConfirmationResult(result);
        setPhone(firebasePhone);

        console.log("TREBA FIREBASE: SMS OTP SENT");

        return;
      }

      /*
       * Driver registration must continue through the
       * driver onboarding workflow before reaching the dashboard.
       *
       * Passenger registration keeps the existing passenger flow.
       */
      if (role === "driver") {
        window.location.href = "/driver/onboarding";
      } else {
        window.location.href = "/app/passenger";
      }
    } catch (err) {
      console.error("=================================");
      console.error("TREBA REGISTRATION FAILED");
      console.error("Error:", err);
      console.error("Message:", err?.message);
      console.error("Code:", err?.code);
      console.error("=================================");

      if (err?.code === "auth/invalid-phone-number") {
        setError(
          "Firebase rejected the mobile number. Please check the number and try again."
        );
      } else if (err?.code === "auth/too-many-requests") {
        setError(
          "Too many verification attempts. Please wait and try again later."
        );
      } else if (err?.code === "auth/quota-exceeded") {
        setError(
          "Firebase SMS verification has reached its current limit. Please try again later."
        );
      } else {
        setError(
          err?.message || "Could not create your account."
        );
      }
    } finally {
      setLoading(false);
    }
  };

  const handleMobileVerify = async () => {
    setError("");

    if (!confirmationResult) {
      setError(
        "Your verification session has expired. Please request a new code."
      );
      return;
    }

    const code = mobileOtp.trim();

    if (!code) {
      setError("Please enter the verification code.");
      return;
    }

    if (code.length !== 6) {
      setError("Please enter the 6-digit verification code.");
      return;
    }

    setLoading(true);

    try {
      console.log("TREBA FIREBASE: Verifying SMS OTP...");

      await confirmationResult.confirm(code);

      console.log("TREBA FIREBASE: SMS OTP VERIFIED");

      const token = localStorage.getItem("treba_token");

      if (!token) {
        throw new Error(
          "Your authentication session could not be found."
        );
      }

      const meResponse = await fetch("/api/auth/me", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const meData = await meResponse.json();

      if (!meResponse.ok) {
        throw new Error(
          meData?.message ||
          "Your authentication session is invalid."
        );
      }

      const authenticatedUser = meData?.user;

      if (!authenticatedUser?.id) {
        throw new Error(
          "Authenticated user could not be found."
        );
      }

      localStorage.setItem(
        "treba_user",
        JSON.stringify(authenticatedUser)
      );

      const profileResponse = await fetch("/api/passengers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          user_id: authenticatedUser.id,
          full_name: fullName.trim(),
          phone: phone.trim(),
          payment_methods: [],
        }),
      });

      const profileData = await profileResponse.json();

      console.log(
        "TREBA PASSENGER PROFILE RESULT:",
        profileData
      );

      if (!profileResponse.ok) {
        const profileMessage =
          profileData?.error ||
          profileData?.message ||
          "";

        if (!profileMessage.toLowerCase().includes("already")) {
          throw new Error(
            profileMessage ||
            "Could not create passenger profile."
          );
        }
      }

      setConfirmationResult(null);

      window.location.href = "/app/passenger";
    } catch (err) {
      console.error("=================================");
      console.error("TREBA PASSENGER REGISTRATION FAILED");
      console.error("Error:", err);
      console.error("Message:", err?.message);
      console.error("Code:", err?.code);
      console.error("=================================");

      if (err?.code === "auth/invalid-verification-code") {
        setError(
          "Incorrect verification code. Please check the SMS and try again."
        );
      } else if (err?.code === "auth/code-expired") {
        setError(
          "This verification code has expired. Please request a new code."
        );
        setConfirmationResult(null);
      } else if (err?.code === "auth/too-many-requests") {
        setError(
          "Too many verification attempts. Please wait and try again later."
        );
      } else {
        setError(
          err?.message ||
          "Could not verify your mobile number."
        );
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    setError(
      "Google registration will be enabled after the Treba authentication migration is complete."
    );
  };

  const accountContent = (
    <div className={embedded
      ? "rounded-2xl border border-border bg-card p-6 shadow-xl sm:p-8"
      : ""
    }>
      <div className="mb-6">
        <h2 className="text-2xl font-bold tracking-tight">
          Create your account
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Get started with Treba
        </p>
      </div>

      {error && (
        <div className="mb-5 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          {error}
        </div>
      )}

      <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-muted p-1">
        <button
          type="button"
          onClick={() => setRole("passenger")}
          className={`rounded-lg px-3 py-2.5 text-sm font-semibold transition ${
            role === "passenger"
              ? "bg-background shadow-sm"
              : "text-muted-foreground"
          }`}
        >
          Passenger
        </button>

        <button
          type="button"
          onClick={() => setRole("driver")}
          className={`rounded-lg px-3 py-2.5 text-sm font-semibold transition ${
            role === "driver"
              ? "bg-background shadow-sm"
              : "text-muted-foreground"
          }`}
        >
          Driver
        </button>
      </div>

      <form onSubmit={handleAccountSubmit} className="space-y-4">
        <div>
          <Label htmlFor="fullName">Full Name</Label>
          <div className="relative mt-1.5">
            <UserPlus className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="fullName"
              value={fullName}
              onChange={(event) => setFullName(event.target.value)}
              placeholder="Your full name"
              className="h-11 pl-9"
              autoComplete="name"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="phone">Mobile Number</Label>
          <div className="relative mt-1.5">
            <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="phone"
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              placeholder="+264 81 123 4567"
              className="h-11 pl-9"
              autoComplete="tel"
            />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            A verification code will be sent by SMS.
          </p>
        </div>

        <div>
          <Label htmlFor="password">Password</Label>
          <div className="relative mt-1.5">
            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="At least 8 characters"
              className="h-11 pl-9"
              autoComplete="new-password"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="confirmPassword">
            Confirm Password
          </Label>
          <div className="relative mt-1.5">
            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(event) =>
                setConfirmPassword(event.target.value)
              }
              placeholder="Repeat your password"
              className="h-11 pl-9"
              autoComplete="new-password"
            />
          </div>
        </div>

        <Button
          type="submit"
          disabled={loading}
          className="h-11 w-full font-semibold"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating account...
            </>
          ) : (
            "Create account"
          )}
        </Button>
      </form>

      <div className="my-5 flex items-center gap-3">
        <div className="h-px flex-1 bg-border" />
        <span className="text-xs text-muted-foreground">
          OR
        </span>
        <div className="h-px flex-1 bg-border" />
      </div>

      <Button
        type="button"
        variant="outline"
        onClick={handleGoogle}
        className="h-11 w-full"
      >
        <GoogleIcon className="mr-2 h-4 w-4" />
        Continue with Google
      </Button>

      <p className="mt-5 text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link
          to="/login"
          className="font-semibold text-primary hover:underline"
        >
          Log in
        </Link>
      </p>
    </div>
  );

  const otpContent = (
    <div className={embedded
      ? "rounded-2xl border border-border bg-card p-6 shadow-xl sm:p-8"
      : ""
    }>
      <div className="mb-6">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
          <ShieldCheck className="h-6 w-6" />
        </div>

        <h2 className="text-2xl font-bold tracking-tight">
          Verify your mobile number
        </h2>

        <p className="mt-2 text-sm text-muted-foreground">
          Enter the 6-digit code sent to{" "}
          <span className="font-semibold text-foreground">
            {phone}
          </span>
        </p>
      </div>

      {error && (
        <div className="mb-5 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          {error}
        </div>
      )}

      <div>
        <Label htmlFor="mobileOtp">
          Verification Code
        </Label>

        <Input
          id="mobileOtp"
          value={mobileOtp}
          onChange={(event) =>
            setMobileOtp(
              event.target.value
                .replace(/\D/g, "")
                .slice(0, 6)
            )
          }
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={6}
          placeholder="123456"
          className="mt-1.5 h-12 text-center text-lg tracking-widest"
          autoFocus
        />

        <div id="recaptcha-container" className="mt-4" />
      </div>

      <Button
        type="button"
        onClick={handleMobileVerify}
        disabled={loading}
        className="mt-5 h-11 w-full font-semibold"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Verifying...
          </>
        ) : (
          "Verify & Continue"
        )}
      </Button>
    </div>
  );

  if (embedded) {
    return step === "passengerOtp"
      ? otpContent
      : accountContent;
  }

  if (step === "passengerOtp") {
    return (
      <AuthLayout
        icon={ShieldCheck}
        title="Verify your mobile number"
        subtitle="Complete SMS verification to continue"
      >
        {otpContent}
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      icon={UserPlus}
      title="Create your account"
      subtitle="Sign up to get started"
    >
      {accountContent}
    </AuthLayout>
  );
}

