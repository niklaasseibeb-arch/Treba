﻿"use strict";

/*
 * Treba Scheduling Worker
 *
 * Responsibilities:
 * 1. Look approximately 24 hours ahead for active driver routes.
 * 2. Create allocation/scheduling pools for routes that are due.
 * 3. Keep the process idempotent so repeated worker runs do not create duplicates.
 * 4. Process existing scheduling pools so expired/declined requests advance.
 *
 * Environment variables:
 * TREBA_SCHEDULING_WORKER_ENABLED=true|false   default true
 * TREBA_SCHEDULING_LEAD_HOURS=24              default 24
 * TREBA_SCHEDULING_TARGET_VEHICLES=1          default 1
 * TREBA_SCHEDULING_INTERVAL_MS=300000         default 5 minutes
 */

const dbModule = require("./db.cjs");
const allocationModule = require("./allocation-orchestrator.cjs");

const pool =
  dbModule?.pool ||
  dbModule?.default ||
  dbModule;

const LEAD_HOURS = Number(process.env.TREBA_SCHEDULING_LEAD_HOURS || 24);
const DEFAULT_TARGET_VEHICLES = Math.max(
  1,
  Number(process.env.TREBA_SCHEDULING_TARGET_VEHICLES || 1)
);
const INTERVAL_MS = Math.max(
  60_000,
  Number(process.env.TREBA_SCHEDULING_INTERVAL_MS || 300_000)
);

let workerRunning = false;

function log(...args) {
  console.log("[Treba Scheduling Worker]", ...args);
}

function asDateOnly(date) {
  return date.toISOString().slice(0, 10);
}

function addDays(date, days) {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}

function normaliseFrequency(value) {
  return String(value || "").trim().toUpperCase();
}

function isRouteActiveForDate(route, date) {
  const frequency = normaliseFrequency(route.frequency);

  if (
    frequency.includes("MON") &&
    frequency.includes("FRI") &&
    !frequency.includes("EVERY")
  ) {
    const day = date.getDay();
    return day >= 1 && day <= 5;
  }

  if (
    frequency === "WEEKDAYS" ||
    frequency === "MONDAY_FRIDAY" ||
    frequency === "MONDAY-FRIDAY"
  ) {
    const day = date.getDay();
    return day >= 1 && day <= 5;
  }

  return true;
}

function pickFunction(moduleObject, names) {
  for (const name of names) {
    if (typeof moduleObject?.[name] === "function") {
      return moduleObject[name];
    }
  }
  return null;
}

async function ensureWorkerTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_scheduling_worker_runs (
      id SERIAL PRIMARY KEY,
      driver_route_id INTEGER NOT NULL,
      travel_date DATE NOT NULL,
      time_block_code VARCHAR(50) NOT NULL,
      target_vehicles INTEGER NOT NULL DEFAULT 1,
      pool_id INTEGER NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
      attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(driver_route_id, travel_date, time_block_code)
    )
  `);
}

async function claimRoute(routeId, travelDate, timeBlockCode, targetVehicles) {
  const result = await pool.query(
    `
      INSERT INTO treba_scheduling_worker_runs
        (
          driver_route_id,
          travel_date,
          time_block_code,
          target_vehicles,
          status,
          attempts,
          updated_at
        )
      VALUES ($1, $2, $3, $4, 'PENDING', 0, CURRENT_TIMESTAMP)
      ON CONFLICT (driver_route_id, travel_date, time_block_code)
      DO UPDATE SET
        target_vehicles = EXCLUDED.target_vehicles,
        updated_at = CURRENT_TIMESTAMP
      RETURNING *
    `,
    [routeId, travelDate, timeBlockCode, targetVehicles]
  );

  return result.rows[0];
}

async function markRun(id, patch) {
  const fields = [];
  const values = [];
  let index = 1;

  for (const [key, value] of Object.entries(patch)) {
    fields.push(`${key} = $${index++}`);
    values.push(value);
  }

  fields.push(`updated_at = CURRENT_TIMESTAMP`);
  values.push(id);

  await pool.query(
    `
      UPDATE treba_scheduling_worker_runs
      SET ${fields.join(", ")}
      WHERE id = $${index}
    `,
    values
  );
}

async function getCandidateRoutes() {
  const result = await pool.query(`
    SELECT
      r.id,
      r.origin_town,
      r.destination_town,
      r.frequency,
      r.direction,
      r.time_block_code,
      r.preferred_departure_time,
      r.corridor_starting_fare,
      r.seat_capacity,
      r.vehicle_id
    FROM treba_driver_routes r
    WHERE COALESCE(r.status, 'ACTIVE') = 'ACTIVE'
    ORDER BY r.origin_town, r.destination_town, r.time_block_code, r.id
  `);

  return result.rows;
}

async function routeHasAvailability(routeId, travelDate, timeBlockCode) {
  try {
    const result = await pool.query(
      `
        SELECT available
        FROM treba_driver_route_availability
        WHERE driver_route_id = $1
          AND (
            travel_date = $2
            OR LOWER(COALESCE(day_of_week, '')) =
               LOWER(TRIM(TO_CHAR($2::date, 'Day')))
            OR LOWER(COALESCE(day_of_week, '')) =
               LOWER(TO_CHAR($2::date, 'Dy'))
          )
          AND (
            time_block_code = $3
            OR time_block_code IS NULL
          )
        ORDER BY
          CASE WHEN travel_date = $2 THEN 0 ELSE 1 END
        LIMIT 1
      `,
      [routeId, travelDate, timeBlockCode]
    );

    if (!result.rows.length) {
      return true;
    }

    return result.rows[0].available !== false;
  } catch (error) {
    /*
     * Availability data is an enhancement layer.
     * If the deployment uses an older availability schema,
     * keep frequency-based route scheduling operational.
     */
    log(
      `Availability lookup skipped for route ${routeId}: ${error.message}`
    );
    return true;
  }
}

function getAllocationCreator() {
  return pickFunction(allocationModule, [
    "createAllocation",
    "createAllocationPool",
    "allocateRoute",
    "runAllocation",
    "createRouteAllocation",
  ]);
}

async function createAllocation(route, travelDate, targetVehicles) {
  const createFn = getAllocationCreator();

  if (!createFn) {
    throw new Error(
      "No compatible allocation creation function was exported by allocation-orchestrator.cjs"
    );
  }

  /*
   * The payload intentionally includes the canonical property names used
   * throughout the Treba allocation design, while retaining aliases for
   * compatibility with the current orchestrator implementation.
   */
  const payload = {
    routeId: route.id,
    driverRouteId: route.id,

    originTown: route.origin_town,
    destinationTown: route.destination_town,

    origin_town: route.origin_town,
    destination_town: route.destination_town,

    travelDate,
    travel_date: travelDate,

    timeBlockCode: route.time_block_code,
    time_block_code: route.time_block_code,

    targetVehicles,
    target_vehicles: targetVehicles,
    requiredVehicles: targetVehicles,

    direction: route.direction,
    preferredDepartureTime: route.preferred_departure_time,
    corridorStartingFare: route.corridor_starting_fare,
    seatCapacity: route.seat_capacity,
    vehicleId: route.vehicle_id,
  };

  return await createFn(payload);
}

function extractPoolId(result) {
  if (result == null) return null;

  if (typeof result === "number") return result;

  if (typeof result === "string" && /^\d+$/.test(result)) {
    return Number(result);
  }

  const candidates = [
    result.poolId,
    result.pool_id,
    result.schedulingPoolId,
    result.scheduling_pool_id,
    result.id,
    result.pool?.id,
    result.pool?.poolId,
    result.data?.poolId,
    result.data?.pool_id,
    result.data?.id,
    result.data?.pool?.id,
  ];

  for (const candidate of candidates) {
    if (candidate !== null && candidate !== undefined && candidate !== "") {
      const number = Number(candidate);
      if (Number.isFinite(number)) return number;
    }
  }

  return null;
}

async function processPool(poolId) {
  const processFn = pickFunction(
    require("./scheduling.cjs"),
    [
      "processSchedulingPool",
      "processPool",
      "processSchedulingQueue",
    ]
  );

  if (processFn) {
    return await processFn(poolId);
  }

  /*
   * Fallback to the HTTP endpoint in the normal server process.
   * This keeps the worker compatible even when scheduling.cjs exposes
   * route handlers rather than direct functions.
   */
  const baseUrl =
    process.env.TREBA_INTERNAL_BASE_URL ||
    `http://127.0.0.1:${process.env.PORT || 5000}`;

  const response = await fetch(
    `${baseUrl}/api/scheduling/pool/${encodeURIComponent(poolId)}/process`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    }
  );

  if (!response.ok) {
    const text = await response.text();
    throw new Error(
      `Scheduling process endpoint returned ${response.status}: ${text}`
    );
  }

  try {
    return await response.json();
  } catch {
    return { ok: true };
  }
}

async function processExistingPools() {
  let processed = 0;

  const result = await pool.query(`
    SELECT pool_id
    FROM treba_scheduling_worker_runs
    WHERE pool_id IS NOT NULL
      AND status IN ('POOL_CREATED', 'PROCESSING', 'PENDING')
    ORDER BY travel_date, time_block_code, id
  `);

  for (const row of result.rows) {
    try {
      await processPool(row.pool_id);
      processed += 1;
      await markRun(row.id, {
        status: "PROCESSING",
        last_error: null,
      });
    } catch (error) {
      await markRun(row.id, {
        status: "PENDING",
        last_error: error.message,
      });

      log(`Pool ${row.pool_id} processing failed: ${error.message}`);
    }
  }

  return processed;
}

async function createDuePools() {
  const now = new Date();
  const dueDate = asDateOnly(
    addDays(now, Math.max(1, Math.round(LEAD_HOURS / 24)))
  );

  const routes = await getCandidateRoutes();
  let considered = 0;
  let created = 0;
  let skipped = 0;

  for (const route of routes) {
    if (!route.time_block_code) {
      skipped += 1;
      continue;
    }

    const dateObject = new Date(`${dueDate}T12:00:00`);
    if (!isRouteActiveForDate(route, dateObject)) {
      continue;
    }

    const available = await routeHasAvailability(
      route.id,
      dueDate,
      route.time_block_code
    );

    if (!available) {
      continue;
    }

    considered += 1;

    const claimed = await claimRoute(
      route.id,
      dueDate,
      route.time_block_code,
      DEFAULT_TARGET_VEHICLES
    );

    if (
      claimed.pool_id &&
      ["POOL_CREATED", "PROCESSING", "COMPLETED"].includes(claimed.status)
    ) {
      continue;
    }

    try {
      await markRun(claimed.id, {
        status: "PROCESSING",
        attempts: Number(claimed.attempts || 0) + 1,
        last_error: null,
      });

      const result = await createAllocation(
        route,
        dueDate,
        DEFAULT_TARGET_VEHICLES
      );

      const poolId = extractPoolId(result);

      if (poolId) {
        await markRun(claimed.id, {
          pool_id: poolId,
          status: "POOL_CREATED",
          last_error: null,
        });

        created += 1;
        log(
          `Created scheduling pool ${poolId} for route ${route.origin_town} -> ${route.destination_town} on ${dueDate} (${route.time_block_code})`
        );
      } else {
        await markRun(claimed.id, {
          status: "PENDING",
          last_error:
            "Allocation function returned successfully but no pool ID was found.",
        });

        log(
          `Allocation returned no pool ID for route ${route.origin_town} -> ${route.destination_town}`
        );
      }
    } catch (error) {
      await markRun(claimed.id, {
        status: "PENDING",
        last_error: error.message,
      });

      log(
        `Allocation failed for route ${route.origin_town} -> ${route.destination_town}: ${error.message}`
      );
    }
  }

  return {
    dueDate,
    totalRoutes: routes.length,
    considered,
    created,
    skipped,
  };
}

async function runSchedulingWorker(options = {}) {
  if (workerRunning) {
    return {
      ok: true,
      skipped: true,
      reason: "Worker run already in progress",
    };
  }

  workerRunning = true;

  try {
    await ensureWorkerTable();

    const created = await createDuePools();
    const processedPools = await processExistingPools();

    const result = {
      ok: true,
      timestamp: new Date().toISOString(),
      leadHours: LEAD_HOURS,
      targetVehicles: DEFAULT_TARGET_VEHICLES,
      intervalMs: INTERVAL_MS,
      created,
      processedPools,
    };

    log(JSON.stringify(result));
    return result;
  } finally {
    workerRunning = false;
  }
}

function startSchedulingWorker() {
  const enabled =
    String(process.env.TREBA_SCHEDULING_WORKER_ENABLED || "true").toLowerCase() !==
    "false";

  if (!enabled) {
    log("Automatic worker disabled by TREBA_SCHEDULING_WORKER_ENABLED=false");
    return null;
  }

  const initialDelay = 10_000;

  const timer = setInterval(() => {
    runSchedulingWorker().catch((error) => {
      log(`Worker run failed: ${error.message}`);
    });
  }, INTERVAL_MS);

  setTimeout(() => {
    runSchedulingWorker().catch((error) => {
      log(`Initial worker run failed: ${error.message}`);
    });
  }, initialDelay);

  log(
    `Automatic scheduling worker started. Interval=${INTERVAL_MS}ms, lead=${LEAD_HOURS}h, targetVehicles=${DEFAULT_TARGET_VEHICLES}`
  );

  return timer;
}

module.exports = {
  runSchedulingWorker,
  startSchedulingWorker,
  INTERVAL_MS,
  LEAD_HOURS,
  DEFAULT_TARGET_VEHICLES,
};

