﻿"use strict";

/*
 * TREBA DRIVER ROUTES / AVAILABILITY
 *
 * Canonical driver route model used by:
 *   Route Setup
 *   Fare Engine
 *   Eligibility Engine
 *   Allocation Orchestrator
 *   Scheduling Engine
 */

const TIME_BLOCKS = {
  "05_09": {
    label: "05:00–09:00",
    start: "05:00",
    end: "09:00",
  },
  "09_12": {
    label: "09:00–12:00",
    start: "09:00",
    end: "12:00",
  },
};

function requireDriver(req) {
  const driverId = Number(req.auth?.id);

  if (!Number.isInteger(driverId) || driverId <= 0) {
    throw new Error("Authentication required.");
  }

  return driverId;
}

function cleanText(value, fallback = "") {
  return String(value ?? fallback).trim();
}

function positiveNumber(value, field) {
  const number = Number(value);

  if (!Number.isFinite(number) || number <= 0) {
    throw new Error(`${field} must be greater than zero.`);
  }

  return number;
}

function optionalPositiveNumber(value, field) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return null;
  }

  return positiveNumber(value, field);
}

function validTimeBlock(value) {
  const code = cleanText(value);

  if (!TIME_BLOCKS[code]) {
    throw new Error(
      "time_block_code must be 05_09 or 09_12."
    );
  }

  return code;
}

async function ensureDriverRouteSchema(pool) {

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_driver_routes (
      id BIGSERIAL PRIMARY KEY,

      driver_id BIGINT NOT NULL,

      origin_town VARCHAR(120) NOT NULL,
      destination_town VARCHAR(120) NOT NULL,

      frequency VARCHAR(30) NOT NULL DEFAULT 'EVERY_DAY',
      direction VARCHAR(20) NOT NULL DEFAULT 'ONE_WAY',

      time_block_code VARCHAR(30) NOT NULL,
      preferred_departure_time TIME NOT NULL,

      standard_pickup_point TEXT,
      standard_dropoff_point TEXT,

      corridor_starting_fare NUMERIC(12,2) NOT NULL
        CHECK (corridor_starting_fare >= 60),

      vehicle_id BIGINT,
      seat_capacity INTEGER NOT NULL
        CHECK (seat_capacity > 0),

      status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_driver_routes_driver
    ON treba_driver_routes(driver_id, status)
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_driver_routes_corridor
    ON treba_driver_routes(
      origin_town,
      destination_town,
      status
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_driver_route_stops (
      id BIGSERIAL PRIMARY KEY,

      route_id BIGINT NOT NULL
        REFERENCES treba_driver_routes(id)
        ON DELETE CASCADE,

      stop_order INTEGER NOT NULL
        CHECK (stop_order >= 1),

      town VARCHAR(120) NOT NULL,

      distance_from_origin_km NUMERIC(10,2),

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      UNIQUE(route_id, stop_order),
      UNIQUE(route_id, town)
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_driver_route_stops_route
    ON treba_driver_route_stops(route_id, stop_order)
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treba_driver_route_availability (
      id BIGSERIAL PRIMARY KEY,

      driver_id BIGINT NOT NULL,
      route_id BIGINT NOT NULL
        REFERENCES treba_driver_routes(id)
        ON DELETE CASCADE,

      day_of_week SMALLINT,

      travel_date DATE,

      available BOOLEAN NOT NULL DEFAULT TRUE,

      start_time TIME,
      end_time TIME,

      time_block_code VARCHAR(30) NOT NULL,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      CHECK (
        day_of_week IS NOT NULL
        OR travel_date IS NOT NULL
      )
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS
      idx_treba_driver_route_availability_driver
    ON treba_driver_route_availability(
      driver_id,
      available
    )
  `);
}

/*
 * Create a route plus its ordered stops and recurring availability.
 */
async function createDriverRoute(pool, driverId, payload) {

  const origin =
    cleanText(payload.origin_town);

  const destination =
    cleanText(payload.destination_town);

  if (!origin || !destination) {
    throw new Error(
      "Origin and destination towns are required."
    );
  }

  if (
    origin.toLowerCase() ===
    destination.toLowerCase()
  ) {
    throw new Error(
      "Origin and destination must be different."
    );
  }

  const frequency =
    cleanText(
      payload.frequency,
      "EVERY_DAY"
    ).toUpperCase();

  const direction =
    cleanText(
      payload.direction,
      "ONE_WAY"
    ).toUpperCase();

  const timeBlockCode =
    validTimeBlock(
      payload.time_block_code
    );

  const departure =
    cleanText(
      payload.preferred_departure_time
    );

  if (!/^\d{2}:\d{2}$/.test(departure)) {
    throw new Error(
      "Preferred departure time must use HH:MM."
    );
  }

  const startingFare =
    positiveNumber(
      payload.corridor_starting_fare,
      "corridor_starting_fare"
    );

  if (startingFare < 60) {
    throw new Error(
      "Starting fare cannot be below N$60."
    );
  }

  const seatCapacity =
    positiveNumber(
      payload.seat_capacity,
      "seat_capacity"
    );

  if (!Number.isInteger(seatCapacity)) {
    throw new Error(
      "seat_capacity must be a whole number."
    );
  }

  const stops =
    Array.isArray(payload.stops)
      ? payload.stops
      : [];

  const client =
    await pool.connect();

  try {

    await client.query("BEGIN");

    const routeResult =
      await client.query(
        `
        INSERT INTO treba_driver_routes (
          driver_id,
          origin_town,
          destination_town,
          frequency,
          direction,
          time_block_code,
          preferred_departure_time,
          standard_pickup_point,
          standard_dropoff_point,
          corridor_starting_fare,
          vehicle_id,
          seat_capacity
        )
        VALUES (
          $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12
        )
        RETURNING *
        `,
        [
          driverId,
          origin,
          destination,
          frequency,
          direction,
          timeBlockCode,
          departure,
          cleanText(
            payload.standard_pickup_point
          ) || null,
          cleanText(
            payload.standard_dropoff_point
          ) || null,
          startingFare,
          payload.vehicle_id
            ? Number(payload.vehicle_id)
            : null,
          seatCapacity,
        ]
      );

    const route =
      routeResult.rows[0];

    const routeStops = [
      {
        town: origin,
        distance:
          optionalPositiveNumber(
            payload.origin_distance_km,
            "origin_distance_km"
          ) ?? 0,
      },
      ...stops.map(
        (stop) => ({
          town: cleanText(stop.town),
          distance:
            optionalPositiveNumber(
              stop.distance_from_origin_km,
              "distance_from_origin_km"
            ),
        })
      ),
      {
        town: destination,
        distance:
          optionalPositiveNumber(
            payload.destination_distance_km,
            "destination_distance_km"
          ),
      },
    ];

    const seen = new Set();

    let order = 1;

    for (const stop of routeStops) {

      const town =
        cleanText(stop.town);

      if (!town) {
        continue;
      }

      const key =
        town.toLowerCase();

      if (seen.has(key)) {
        continue;
      }

      seen.add(key);

      await client.query(
        `
        INSERT INTO treba_driver_route_stops (
          route_id,
          stop_order,
          town,
          distance_from_origin_km
        )
        VALUES ($1,$2,$3,$4)
        `,
        [
          route.id,
          order,
          town,
          stop.distance ?? null,
        ]
      );

      order++;
    }

    /*
     * Store recurring availability for each applicable weekday.
     */
    const weekdays =
      frequency === "MONDAY_FRIDAY"
        ? [1,2,3,4,5]
        : [0,1,2,3,4,5,6];

    const block =
      TIME_BLOCKS[timeBlockCode];

    for (const day of weekdays) {

      await client.query(
        `
        INSERT INTO treba_driver_route_availability (
          driver_id,
          route_id,
          day_of_week,
          available,
          start_time,
          end_time,
          time_block_code
        )
        VALUES ($1,$2,$3,TRUE,$4,$5,$6)
        `,
        [
          driverId,
          route.id,
          day,
          block.start,
          block.end,
          timeBlockCode,
        ]
      );
    }

    await client.query("COMMIT");

    return route;

  } catch (error) {

    try {
      await client.query("ROLLBACK");
    } catch {}

    throw error;

  } finally {
    client.release();
  }
}

async function getDriverRoutes(
  pool,
  driverId
) {

  const routeResult =
    await pool.query(
      `
      SELECT *
      FROM treba_driver_routes
      WHERE driver_id = $1
        AND status = 'ACTIVE'
      ORDER BY created_at DESC
      `,
      [driverId]
    );

  const routes = [];

  for (const route of routeResult.rows) {

    const stops =
      await pool.query(
        `
        SELECT
          id,
          stop_order,
          town,
          distance_from_origin_km
        FROM treba_driver_route_stops
        WHERE route_id = $1
        ORDER BY stop_order
        `,
        [route.id]
      );

    const availability =
      await pool.query(
        `
        SELECT
          id,
          day_of_week,
          travel_date,
          available,
          start_time,
          end_time,
          time_block_code
        FROM treba_driver_route_availability
        WHERE route_id = $1
        ORDER BY day_of_week NULLS LAST, travel_date NULLS LAST
        `,
        [route.id]
      );

    routes.push({
      ...route,
      stops: stops.rows,
      availability: availability.rows,
    });
  }

  return routes;
}

async function deleteDriverRoute(
  pool,
  driverId,
  routeId
) {

  const result =
    await pool.query(
      `
      UPDATE treba_driver_routes
      SET
        status = 'INACTIVE',
        updated_at = NOW()
      WHERE id = $1
        AND driver_id = $2
        AND status = 'ACTIVE'
      RETURNING id
      `,
      [
        Number(routeId),
        driverId,
      ]
    );

  return result.rows.length > 0;
}

function registerDriverRouteRoutes(
  app,
  pool
) {

  app.get(
    "/api/driver/routes",
    async (req, res) => {

      try {

        const driverId =
          requireDriver(req);

        await ensureDriverRouteSchema(
          pool
        );

        const routes =
          await getDriverRoutes(
            pool,
            driverId
          );

        return res.json({
          ok: true,
          routes,
          timeBlocks: TIME_BLOCKS,
        });

      } catch (error) {

        console.error(
          "GET /api/driver/routes:",
          error
        );

        return res.status(401).json({
          ok: false,
          message:
            error.message ||
            "Unable to load driver routes.",
        });
      }
    }
  );

  app.post(
    "/api/driver/routes",
    async (req, res) => {

      try {

        const driverId =
          requireDriver(req);

        await ensureDriverRouteSchema(
          pool
        );

        const route =
          await createDriverRoute(
            pool,
            driverId,
            req.body || {}
          );

        return res.status(201).json({
          ok: true,
          route,
          message:
            "Driver route saved successfully.",
        });

      } catch (error) {

        console.error(
          "POST /api/driver/routes:",
          error
        );

        return res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to save driver route.",
        });
      }
    }
  );

  app.delete(
    "/api/driver/routes/:id",
    async (req, res) => {

      try {

        const driverId =
          requireDriver(req);

        await ensureDriverRouteSchema(
          pool
        );

        const deleted =
          await deleteDriverRoute(
            pool,
            driverId,
            req.params.id
          );

        if (!deleted) {
          return res.status(404).json({
            ok: false,
            message:
              "Route not found.",
          });
        }

        return res.json({
          ok: true,
          message:
            "Route deactivated.",
        });

      } catch (error) {

        console.error(
          "DELETE /api/driver/routes/:id:",
          error
        );

        return res.status(400).json({
          ok: false,
          message:
            error.message ||
            "Unable to deactivate route.",
        });
      }
    }
  );
}

module.exports = {
  TIME_BLOCKS,
  ensureDriverRouteSchema,
  createDriverRoute,
  getDriverRoutes,
  deleteDriverRoute,
  registerDriverRouteRoutes,
};
